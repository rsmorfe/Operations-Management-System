﻿Imports MySql.Data.MySqlClient
Public Class Dashboard

    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim query = "Select Count(*) from users"
        Dim query1 = "Select Count(*) from products"
        Dim query2 = "Select Count(*) from transactionhistory WHERE is_voided = 0"
        'Dim query3 = "Select Count(*) from supplier"
        Dim query4 = "SELECT COUNT(*) FROM products a WHERE ((COALESCE(" & _
                     "(SELECT SUM(quantity) FROM stockhistory b WHERE b.prod_id = a.prod_id AND " & _
                     "stock_type = 'REPLENISH'),0)) - " & _
                     "(COALESCE((SELECT SUM(quantity) FROM stockhistory b WHERE b.prod_id = a.prod_id AND " & _
                     "stock_type = 'CHECKOUT'),0))) < " & stockLevelCriticalValue(10)

        Dim cmd As MySqlCommand
        Dim cmd1 As MySqlCommand
        Dim cmd2 As MySqlCommand
        Dim cmd3 As MySqlCommand
        Dim cmd4 As MySqlCommand

        openConnection()

        'TOTAL NUMBER OF USERS
        cmd = New MySqlCommand(query, MysqlConn)
        Dim count As Int16 = Convert.ToInt16(cmd.ExecuteScalar())
        lblUser.Text = count.ToString()

        'TOTAL NUMBER OF PROUCTS
        cmd1 = New MySqlCommand(query1, MysqlConn)
        Dim count1 As Int16 = Convert.ToInt16(cmd1.ExecuteScalar())
        lblProducts.Text = count1.ToString()

        'TOTAL NUMBER OF CATEGORY
        cmd2 = New MySqlCommand(query2, MysqlConn)
        Dim count2 As Int16 = Convert.ToInt16(cmd2.ExecuteScalar())
        lblCategory.Text = count2.ToString()

        'TOTAL NUMBER OF SUPPLIERS
        'cmd3 = New MySqlCommand(query3, MysqlConn)
        'Dim count3 As Int16 = Convert.ToInt16(cmd3.ExecuteScalar())
        'lblSupplier.Text = count3.ToString()

        'TOTAL NUMBER OF PRODUCTS WITH CRITICAL STOCK LEVEL
        cmd4 = New MySqlCommand(query4, MysqlConn)
        Dim count4 As Int16 = Convert.ToInt16(cmd4.ExecuteScalar())
        lblCriticalStockLevell.Text = count4.ToString()

        closeConnection()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class