﻿Public Class Create_Account

    Private Sub Create_Account_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Userlist()
        loadUserLevel()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        If cbUserLevel.Text = "" Or txtFName.Text = "" Or txtLName.Text = "" Or txtUser.Text = "" Or txtPass.Text = "" Then
            MessageBox.Show("Incomplete Data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            createAccount(txtFName.Text, txtLName.Text, txtUser.Text, txtPass.Text, Integer.Parse(cbUserLevel.Text))
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        clearFields()
    End Sub

    Private Sub dgbUser_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgbUser.CellClick
        If dgbUser.Rows.Count > 0 Then
            btnSetStatus.Enabled = True
        End If
    End Sub


    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Then
                MsgBox("Please enter the name of the user", vbInformation + vbOKOnly, "System")
                txtSearch.Focus()
            Else
                searchUser(txtSearch.Text)
            End If
        End If
    End Sub

    Sub loadUserLevel()
        cbUserLevel.Items.Clear()

        cbUserLevel.Items.Add("1")
        cbUserLevel.Items.Add("2")
        cbUserLevel.Items.Add("3")
    End Sub
    Public Sub Userlist()
        Try
            openConnection()

            Dim dt As New DataTable
            Dim sql = "select user_id, LastName,FirstName,User_Name,User_Level," _
                      & "User_Status from users"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            closeConnection()
            dgbUser.DataSource = dt

            dgbUser.Columns.Item(0).HeaderText = "ID"
            dgbUser.Columns.Item(1).HeaderText = "Last Name"
            dgbUser.Columns.Item(2).HeaderText = "First Name"
            dgbUser.Columns.Item(3).HeaderText = "User Name"
            dgbUser.Columns.Item(4).HeaderText = "User Level"
            dgbUser.Columns.Item(5).HeaderText = "User Status"
            dgbUser.Columns.Item(5).Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        txtSearch.Focus()
    End Sub

    Sub searchUser(name As String)
        Try
            openConnection()

            Dim dt As New DataTable
            Dim sql = "select user_id, LastName,FirstName,User_Name,User_Level," _
                      & "User_Status from users WHERE FirstName LIKE @name or LastName LIKE @name"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@name", "%" + name + "%")
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            closeConnection()
            If dt.Rows.Count > 0 Then
                dgbUser.DataSource = dt

                dgbUser.Columns.Item(0).HeaderText = "ID"
                dgbUser.Columns.Item(1).HeaderText = "Last Name"
                dgbUser.Columns.Item(2).HeaderText = "First Name"
                dgbUser.Columns.Item(3).HeaderText = "User Name"
                dgbUser.Columns.Item(4).HeaderText = "User Level"
                dgbUser.Columns.Item(5).HeaderText = "User Status"
                dgbUser.Columns.Item(5).Visible = False
            Else
                MsgBox("No record/s found", vbInformation + vbOKOnly, "System")
                Userlist()
                txtSearch.Clear()
            End If
            
            COMMAND.Parameters.Clear()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub

    Sub createAccount(fname As String, lname As String, user As String, pass As String, level As Integer)
        Try
            Dim stat As Integer = 1
            openConnection()
            Dim query As String
            query = "insert into users (LastName, FirstName, User_Name, User_Pass, User_Level, User_Status)" _
                & "values(@lname,@fname,@username,@userpass,@userlevel,@userstatus)"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = query
                .Parameters.AddWithValue("@lname", lname)
                .Parameters.AddWithValue("@fname", fname)
                .Parameters.AddWithValue("@username", user)
                .Parameters.AddWithValue("@userpass", pass)
                .Parameters.AddWithValue("@userlevel", level)
                .Parameters.AddWithValue("@userstatus", stat)
                .ExecuteNonQuery()
            End With

            MessageBox.Show("New User Added Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            closeConnection()
            clearFields()
            Userlist()

            COMMAND.Parameters.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        COMMAND.Parameters.Clear()
    End Sub

    Sub clearFields()
        cbUserLevel.ResetText()
        cbUserLevel.SelectedIndex = -1
        txtFName.Text = ""
        txtLName.Text = ""
        txtUser.Text = ""
        txtPass.Text = ""
    End Sub

    Private Sub btnSetStatus_Click(sender As Object, e As EventArgs) Handles btnSetStatus.Click
        If dgbUser.SelectedRows.Count > 0 Then
            Dim stat As Integer = dgbUser.CurrentRow.Cells("User_Status").Value
            If stat = 1 Then
                Dim a = MsgBox("Deactivate the selected account?", vbQuestion + vbYesNo, "System")
                If a = vbYes Then
                    openConnection()
                    Dim sql As String
                    sql = "UPDATE users set User_Status = 0 WHERE User_id = @id"

                    With COMMAND
                        .Connection = MysqlConn
                        .CommandText = sql
                        .Parameters.AddWithValue("@id", dgbUser.CurrentRow.Cells("user_id").Value)
                    End With

                    Dim result As Integer

                    result = COMMAND.ExecuteNonQuery()
                    If result > 0 Then
                        MsgBox("Account Deactivated", vbInformation + vbOKOnly, "System")
                        Userlist()
                    End If
                    COMMAND.Parameters.Clear()
                    closeConnection()
                End If
            Else
                Dim a = MsgBox("Activate the selected account?", vbQuestion + vbYesNo, "System")
                If a = vbYes Then
                    openConnection()
                    Dim sql As String
                    sql = "UPDATE users set User_Status = 1 WHERE User_id = @id"

                    With COMMAND
                        .Connection = MysqlConn
                        .CommandText = sql
                        .Parameters.AddWithValue("@id", dgbUser.CurrentRow.Cells("user_id").Value)
                    End With

                    Dim result As Integer

                    result = COMMAND.ExecuteNonQuery()
                    If result > 0 Then
                        MsgBox("Account Activated", vbInformation + vbOKOnly, "System")
                        Userlist()
                    End If
                    COMMAND.Parameters.Clear()
                    closeConnection()
                End If
            End If
        End If
        
    End Sub

    Private Sub quantity_Paint(sender As Object, e As PaintEventArgs) Handles quantity.Paint

    End Sub
End Class