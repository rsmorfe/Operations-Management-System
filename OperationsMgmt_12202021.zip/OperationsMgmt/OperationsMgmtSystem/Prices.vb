﻿Public Class Prices

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Prices_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadprices()
    End Sub

    Sub loadprices()
        Try
            openConnection()

            Dim sql As String
            Dim ds As New DataSet
            sql = "SELECT a.prod_id, a.prod_name as Product_Name, b.prod_price " _
                & "FROM products a LEFT JOIN prices b ON a.prod_id = b.prod_id " _
                & "WHERE cat_id NOT IN (1,2) ORDER BY prod_id"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(ds, "prod_name")

            With dgvPrices
                .DataSource = ds
                .DataMember = "prod_name"
                .Columns.Item(0).HeaderText = "ID"
                .Columns.Item(0).Visible = True
                .Columns.Item(1).HeaderText = "Product Name"
                .Columns.Item(2).HeaderText = "Price"
                .Columns.Item(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
            End With

            closeConnection()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub dgvPrices_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvPrices.CellDoubleClick
        Dim row As DataGridViewRow = dgvPrices.CurrentRow
        prodid.Text = row.Cells(0).Value.ToString()
        prodname.Text = row.Cells(1).Value.ToString()
        prodprice.Text = row.Cells(2).Value.ToString()
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Then
                MsgBox("Please enter the product name", vbInformation + vbOKOnly, "System")
                searchProduct(txtSearch.Text)
                txtSearch.Focus()
            Else
                searchProduct(txtSearch.Text)
            End If
        End If
    End Sub

    Sub searchProduct(item As String)
        Dim sql As String
        Dim dtable As New DataTable

        sql = "SELECT a.prod_id, a.prod_name as Product_Name, b.prod_price " _
                & "FROM products a LEFT JOIN prices b ON a.prod_id = b.prod_id " _
                & "WHERE prod_name LIKE @item AND cat_id NOT IN (1,2) " _
                & "ORDER BY prod_id"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@item", "%" + item + "%")
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)

            If dtable.Rows.Count > 0 Then
                dgvPrices.DataSource = dtable
                dgvPrices.Columns.Item(0).HeaderText = "ID"
                dgvPrices.Columns.Item(0).Visible = True
                dgvPrices.Columns.Item(1).HeaderText = "Product Name"
                dgvPrices.Columns.Item(2).HeaderText = "Price"
                dgvPrices.Columns.Item(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                dgvPrices.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
            Else
                MsgBox("No record/s found", vbInformation + vbOKOnly, "Result")
                txtSearch.Clear()
                loadprices()
                clearFields()
            End If


            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)

            COMMAND.Parameters.Clear()
            closeConnection()
        End Try
    End Sub

    Private Sub prodprice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles prodprice.KeyPress
        Dim DecimalSeparator As String = Application.CurrentCulture.NumberFormat.NumberDecimalSeparator
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                         Asc(e.KeyChar) = 8 Or
                         (e.KeyChar = DecimalSeparator And sender.Text.IndexOf(DecimalSeparator) = -1))

        If Char.IsControl(e.KeyChar) Then
        ElseIf Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "."c Then
            'If TextBox2.TextLength = 5 And TextBox2.Text.Contains(".") = False Then
            'TextBox2.AppendText(".")
            'Elseif
            If e.KeyChar = "." And prodprice.Text.IndexOf(".") <> -1 Then
                e.Handled = True
            ElseIf Char.IsDigit(e.KeyChar) Then
                If prodprice.Text.IndexOf(".") <> -1 Then
                    If prodprice.Text.Length >= prodprice.Text.IndexOf(".") + 3 Then
                        e.Handled = True
                    End If
                End If
            End If
        Else
            e.Handled = True
        End If
    End Sub

    Sub clearFields()
        prodid.Text = ""
        prodname.Text = ""
        prodprice.Text = ""
    End Sub

    Private Sub btnSetPrice_Click(sender As Object, e As EventArgs) Handles btnSetPrice.Click
        If prodid.Text = "" Then
            MsgBox("Select a Product", vbExclamation + vbOKOnly, "System")
        ElseIf Len(Trim(prodprice.Text)) = 0 Or CDbl(prodprice.Text) = 0 Then
            MsgBox("Enter an amount", vbExclamation + vbOKOnly, "System")
        Else
        Dim a = MsgBox("Set Item Price?", vbQuestion + vbYesNo)
        If a = MsgBoxResult.Yes Then
            setItemPrice(prodid.Text, prodprice.Text)
        End If
        End If
    End Sub

    Sub setItemPrice(id As Integer, price As Double)
        Dim sql As String
        Dim dtable As New DataTable

        sql = "SELECT prod_id FROM prices WHERE prod_id = @id"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@id", id)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)
            COMMAND.Parameters.Clear()

            If dtable.Rows.Count > 0 Then
                'UPDATE RECORD
                Try
                    sql = "UPDATE prices set prod_price =" & price & " WHERE prod_id =" & id & ""
                    'we open Connection
                    openConnection()
                    With COMMAND
                        .Connection = MysqlConn
                        .CommandText = sql
                        .ExecuteNonQuery()
                    End With

                    loadprices()
                    clearFields()
                Catch ex As Exception
                    MsgBox(ex.Message)
                    COMMAND.Parameters.Clear()
                End Try
            Else
                'INSERT RECORD
                Dim result As Integer
                Try
                    'we open Connection
                    openConnection()

                    With COMMAND
                        .Connection = MysqlConn
                        .CommandText = "INSERT INTO prices" _
                            & "(prod_id,prod_price) VALUES(@id,@price)"

                        .Parameters.AddWithValue("@id", id)
                        .Parameters.AddWithValue("@price", FormatNumber(price, 2))

                        'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                        result = COMMAND.ExecuteNonQuery
                        'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                        If result = 0 Then
                            MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                        Else
                            COMMAND.Parameters.Clear()
                        End If

                        loadprices()
                        clearFields()
                    End With
                Catch ex As Exception
                    MsgBox(ex.Message)
                    COMMAND.Parameters.Clear()
                End Try
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

            COMMAND.Parameters.Clear()
            closeConnection()
        End Try
    End Sub
End Class