﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Create_Account
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.quantity = New System.Windows.Forms.Panel()
        Me.btnSetStatus = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.cbUserLevel = New System.Windows.Forms.ComboBox()
        Me.txtLName = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnRegister = New System.Windows.Forms.Button()
        Me.txtPass = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtUser = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.txtFName = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblSupp = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.dgbUser = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.pnlHeader.SuspendLayout()
        Me.quantity.SuspendLayout()
        CType(Me.dgbUser, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlHeader
        '
        Me.pnlHeader.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.pnlHeader.Controls.Add(Me.btnExit)
        Me.pnlHeader.Controls.Add(Me.Label1)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(633, 50)
        Me.pnlHeader.TabIndex = 6
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnExit.FlatAppearance.BorderSize = 0
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Linen
        Me.btnExit.Location = New System.Drawing.Point(593, 3)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(31, 42)
        Me.btnExit.TabIndex = 18
        Me.btnExit.TabStop = False
        Me.btnExit.Text = "X"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Linen
        Me.Label1.Location = New System.Drawing.Point(170, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(298, 25)
        Me.Label1.TabIndex = 63
        Me.Label1.Text = "ACCOUNT ADMINISTRATION"
        '
        'quantity
        '
        Me.quantity.BackColor = System.Drawing.Color.Linen
        Me.quantity.Controls.Add(Me.btnSetStatus)
        Me.quantity.Controls.Add(Me.btnClear)
        Me.quantity.Controls.Add(Me.cbUserLevel)
        Me.quantity.Controls.Add(Me.txtLName)
        Me.quantity.Controls.Add(Me.Label5)
        Me.quantity.Controls.Add(Me.btnRegister)
        Me.quantity.Controls.Add(Me.txtPass)
        Me.quantity.Controls.Add(Me.Label4)
        Me.quantity.Controls.Add(Me.Label3)
        Me.quantity.Controls.Add(Me.txtUser)
        Me.quantity.Controls.Add(Me.txtFName)
        Me.quantity.Controls.Add(Me.Label2)
        Me.quantity.Controls.Add(Me.lblSupp)
        Me.quantity.Controls.Add(Me.Button5)
        Me.quantity.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.quantity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.quantity.Location = New System.Drawing.Point(0, 347)
        Me.quantity.Name = "quantity"
        Me.quantity.Size = New System.Drawing.Size(633, 287)
        Me.quantity.TabIndex = 64
        '
        'btnSetStatus
        '
        Me.btnSetStatus.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnSetStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSetStatus.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSetStatus.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSetStatus.Location = New System.Drawing.Point(175, 229)
        Me.btnSetStatus.Name = "btnSetStatus"
        Me.btnSetStatus.Size = New System.Drawing.Size(159, 36)
        Me.btnSetStatus.TabIndex = 8
        Me.btnSetStatus.Text = "Active/Deactivate"
        Me.btnSetStatus.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnClear.Location = New System.Drawing.Point(493, 229)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(121, 36)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'cbUserLevel
        '
        Me.cbUserLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbUserLevel.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbUserLevel.FormattingEnabled = True
        Me.cbUserLevel.Location = New System.Drawing.Point(133, 17)
        Me.cbUserLevel.Name = "cbUserLevel"
        Me.cbUserLevel.Size = New System.Drawing.Size(57, 29)
        Me.cbUserLevel.TabIndex = 3
        '
        'txtLName
        '
        Me.txtLName.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.txtLName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLName.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txtLName.HintForeColor = System.Drawing.Color.Empty
        Me.txtLName.HintText = ""
        Me.txtLName.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.txtLName.isPassword = False
        Me.txtLName.LineFocusedColor = System.Drawing.Color.Blue
        Me.txtLName.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.txtLName.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.txtLName.LineThickness = 4
        Me.txtLName.Location = New System.Drawing.Point(33, 165)
        Me.txtLName.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(276, 33)
        Me.txtLName.TabIndex = 5
        Me.txtLName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(29, 139)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(97, 21)
        Me.Label5.TabIndex = 72
        Me.Label5.Text = "Last Name:"
        '
        'btnRegister
        '
        Me.btnRegister.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRegister.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRegister.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnRegister.Location = New System.Drawing.Point(355, 229)
        Me.btnRegister.Name = "btnRegister"
        Me.btnRegister.Size = New System.Drawing.Size(121, 36)
        Me.btnRegister.TabIndex = 9
        Me.btnRegister.Text = "Register"
        Me.btnRegister.UseVisualStyleBackColor = False
        '
        'txtPass
        '
        Me.txtPass.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.txtPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPass.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPass.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txtPass.HintForeColor = System.Drawing.Color.Empty
        Me.txtPass.HintText = ""
        Me.txtPass.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.txtPass.isPassword = True
        Me.txtPass.LineFocusedColor = System.Drawing.Color.Blue
        Me.txtPass.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.txtPass.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.txtPass.LineThickness = 4
        Me.txtPass.Location = New System.Drawing.Point(416, 165)
        Me.txtPass.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.Size = New System.Drawing.Size(198, 33)
        Me.txtPass.TabIndex = 7
        Me.txtPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(412, 139)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 21)
        Me.Label4.TabIndex = 67
        Me.Label4.Text = "Password:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(412, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 21)
        Me.Label3.TabIndex = 66
        Me.Label3.Text = "Username:"
        '
        'txtUser
        '
        Me.txtUser.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.txtUser.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUser.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUser.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txtUser.HintForeColor = System.Drawing.Color.Empty
        Me.txtUser.HintText = ""
        Me.txtUser.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.txtUser.isPassword = False
        Me.txtUser.LineFocusedColor = System.Drawing.Color.Blue
        Me.txtUser.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.txtUser.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.txtUser.LineThickness = 4
        Me.txtUser.Location = New System.Drawing.Point(416, 94)
        Me.txtUser.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(198, 33)
        Me.txtUser.TabIndex = 6
        Me.txtUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'txtFName
        '
        Me.txtFName.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.txtFName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFName.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txtFName.HintForeColor = System.Drawing.Color.Empty
        Me.txtFName.HintText = ""
        Me.txtFName.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.txtFName.isPassword = False
        Me.txtFName.LineFocusedColor = System.Drawing.Color.Blue
        Me.txtFName.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.txtFName.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.txtFName.LineThickness = 4
        Me.txtFName.Location = New System.Drawing.Point(33, 94)
        Me.txtFName.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(276, 33)
        Me.txtFName.TabIndex = 4
        Me.txtFName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(29, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 21)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "First Name:"
        '
        'lblSupp
        '
        Me.lblSupp.AutoSize = True
        Me.lblSupp.BackColor = System.Drawing.Color.Transparent
        Me.lblSupp.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSupp.ForeColor = System.Drawing.Color.Black
        Me.lblSupp.Location = New System.Drawing.Point(29, 20)
        Me.lblSupp.Name = "lblSupp"
        Me.lblSupp.Size = New System.Drawing.Size(90, 21)
        Me.lblSupp.TabIndex = 29
        Me.lblSupp.Text = "User Level:"
        '
        'Button5
        '
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(0, 540)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(200, 48)
        Me.Button5.TabIndex = 5
        Me.Button5.Text = "Logout"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'dgbUser
        '
        Me.dgbUser.AllowUserToAddRows = False
        Me.dgbUser.AllowUserToDeleteRows = False
        Me.dgbUser.AllowUserToResizeColumns = False
        Me.dgbUser.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.dgbUser.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgbUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgbUser.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.dgbUser.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgbUser.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.MediumSlateBlue
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgbUser.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgbUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgbUser.DoubleBuffered = True
        Me.dgbUser.EnableHeadersVisualStyles = False
        Me.dgbUser.HeaderBgColor = System.Drawing.Color.MediumSlateBlue
        Me.dgbUser.HeaderForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.dgbUser.Location = New System.Drawing.Point(12, 88)
        Me.dgbUser.Name = "dgbUser"
        Me.dgbUser.ReadOnly = True
        Me.dgbUser.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgbUser.RowHeadersVisible = False
        Me.dgbUser.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgbUser.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgbUser.Size = New System.Drawing.Size(602, 240)
        Me.dgbUser.TabIndex = 2
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(12, 56)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(240, 26)
        Me.txtSearch.TabIndex = 1
        '
        'Create_Account
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(633, 634)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.dgbUser)
        Me.Controls.Add(Me.quantity)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Create_Account"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Create_Account"
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.quantity.ResumeLayout(False)
        Me.quantity.PerformLayout()
        CType(Me.dgbUser, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents quantity As System.Windows.Forms.Panel
    Friend WithEvents txtUser As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents txtFName As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblSupp As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtPass As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnRegister As System.Windows.Forms.Button
    Friend WithEvents dgbUser As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents txtLName As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cbUserLevel As System.Windows.Forms.ComboBox
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSetStatus As System.Windows.Forms.Button
End Class
