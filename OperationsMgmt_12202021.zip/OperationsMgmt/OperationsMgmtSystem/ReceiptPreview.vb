﻿Public Class ReceiptPreview
    Public strPrint As String

    Private Sub ReceiptPreview_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtPreview.Text = strPrint
        btnPrint.Focus()
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        Printer.Print(strPrint)
        Me.Close()
    End Sub
End Class