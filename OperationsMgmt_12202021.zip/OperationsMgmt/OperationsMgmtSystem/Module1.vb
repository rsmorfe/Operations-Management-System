﻿Imports MySql.Data.MySqlClient

Module Module1
    Public MysqlConn As MySqlConnection
    Public COMMAND As New MySqlCommand
    Public da As New MySqlDataAdapter

    'User credentials
    Public logged_user_id As Integer
    Public logged_user_level As Integer

    'VAT Configuration
    Public VAT As Double = 0.12
    Public Vatable As Double = 1.12

    'Critical Stock Level value
    Public criticalStockValue As Integer

    'MySQL Connection
    Public db_server As String = "localhost"
    Public db_user As String = "root"
    Public db_pass As String = ""
    Public db_database As String = "dbdonbutchi"

    Public Sub MysqlConnection()
        MysqlConn = New MySqlConnection()

        'Connection String

        Dim connectionstring As String = "server=" & db_server & ";userid=" & db_user & ";password=" & db_pass & ";database=" & db_database
        MysqlConn.ConnectionString = connectionstring
        'MysqlConn.ConnectionString = "server=localhost;userid=root;password= ;database=dbdonbutchi"

        'Opening the Mysql Connection
        Try
            MysqlConn.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub openConnection()
        If MysqlConn.State = ConnectionState.Open Then
            'MessageBox.Show("Connection is open")
        Else
            'MessageBox.Show("Connection is closed")
            MysqlConn.Open()
        End If
    End Sub

    Public Sub closeConnection()
        If MysqlConn.State = ConnectionState.Open Then
            MysqlConn.Close()
        End If
    End Sub

    Public Sub setLoginCredentials(level As Integer)
        If level > 1 Then
            Index.btnCreateAccount.Visible = False
        End If
    End Sub

    Public Sub saveLoggedUser(id As Integer, level As Integer)
        logged_user_id = id
        logged_user_level = level
    End Sub

    Public Function stockLevelCriticalValue(stockValue As Integer)
        criticalStockValue = stockValue
        Return criticalStockValue
    End Function

    Public Function getUserName(id As Integer)
        Dim result As String = ""
        Dim sql As String

        sql = "SELECT CONCAT(FirstName,' ',Lastname) as fullname FROM users " _
            & "WHERE User_id = @id"
        Try
            openConnection()

            Dim dt As New DataTable

            With COMMAND
                .Connection = MysqlConn
                .CommandText = Sql
                .Parameters.AddWithValue("@id", id)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            If dt.Rows.Count > 0 Then
                result = dt.Rows(0).Item(0).ToString
            End If

            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try

        Return result
    End Function
End Module
