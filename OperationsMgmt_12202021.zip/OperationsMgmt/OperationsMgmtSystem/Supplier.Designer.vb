﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Supplier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.VerticalMenu = New System.Windows.Forms.Panel()
        Me.supp_telno = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.supp_name = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.supp_address = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.lblSupp = New System.Windows.Forms.Label()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.supp_id = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.btnInsert = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.dgvSupplier = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        Me.VerticalMenu.SuspendLayout()
        CType(Me.dgvSupplier, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlHeader
        '
        Me.pnlHeader.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.pnlHeader.Controls.Add(Me.Label1)
        Me.pnlHeader.Controls.Add(Me.btnExit)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(950, 50)
        Me.pnlHeader.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Linen
        Me.Label1.Location = New System.Drawing.Point(448, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 25)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "SUPPLIER"
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnExit.FlatAppearance.BorderSize = 0
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Linen
        Me.btnExit.Location = New System.Drawing.Point(916, 3)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(31, 42)
        Me.btnExit.TabIndex = 18
        Me.btnExit.TabStop = False
        Me.btnExit.Text = "X"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'VerticalMenu
        '
        Me.VerticalMenu.BackColor = System.Drawing.Color.Linen
        Me.VerticalMenu.Controls.Add(Me.btnClear)
        Me.VerticalMenu.Controls.Add(Me.supp_telno)
        Me.VerticalMenu.Controls.Add(Me.Label2)
        Me.VerticalMenu.Controls.Add(Me.Button5)
        Me.VerticalMenu.Controls.Add(Me.supp_name)
        Me.VerticalMenu.Controls.Add(Me.supp_address)
        Me.VerticalMenu.Controls.Add(Me.btnDelete)
        Me.VerticalMenu.Controls.Add(Me.lblSupp)
        Me.VerticalMenu.Controls.Add(Me.btnUpdate)
        Me.VerticalMenu.Controls.Add(Me.supp_id)
        Me.VerticalMenu.Controls.Add(Me.btnInsert)
        Me.VerticalMenu.Controls.Add(Me.Label5)
        Me.VerticalMenu.Controls.Add(Me.Label6)
        Me.VerticalMenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.VerticalMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.VerticalMenu.Location = New System.Drawing.Point(0, 50)
        Me.VerticalMenu.Name = "VerticalMenu"
        Me.VerticalMenu.Size = New System.Drawing.Size(349, 550)
        Me.VerticalMenu.TabIndex = 6
        '
        'supp_telno
        '
        Me.supp_telno.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.supp_telno.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.supp_telno.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.supp_telno.HintForeColor = System.Drawing.Color.Empty
        Me.supp_telno.HintText = ""
        Me.supp_telno.isPassword = False
        Me.supp_telno.LineFocusedColor = System.Drawing.Color.Blue
        Me.supp_telno.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.supp_telno.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.supp_telno.LineThickness = 4
        Me.supp_telno.Location = New System.Drawing.Point(16, 315)
        Me.supp_telno.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.supp_telno.Name = "supp_telno"
        Me.supp_telno.Size = New System.Drawing.Size(311, 27)
        Me.supp_telno.TabIndex = 4
        Me.supp_telno.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(14, 289)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(108, 21)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "Contact No:"
        '
        'Button5
        '
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(0, 540)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(200, 48)
        Me.Button5.TabIndex = 5
        Me.Button5.Text = "Logout"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'supp_name
        '
        Me.supp_name.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.supp_name.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.supp_name.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.supp_name.HintForeColor = System.Drawing.Color.Empty
        Me.supp_name.HintText = ""
        Me.supp_name.isPassword = False
        Me.supp_name.LineFocusedColor = System.Drawing.Color.Blue
        Me.supp_name.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.supp_name.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.supp_name.LineThickness = 4
        Me.supp_name.Location = New System.Drawing.Point(14, 148)
        Me.supp_name.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.supp_name.Name = "supp_name"
        Me.supp_name.Size = New System.Drawing.Size(311, 25)
        Me.supp_name.TabIndex = 2
        Me.supp_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'supp_address
        '
        Me.supp_address.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.supp_address.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.supp_address.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.supp_address.HintForeColor = System.Drawing.Color.Empty
        Me.supp_address.HintText = ""
        Me.supp_address.isPassword = False
        Me.supp_address.LineFocusedColor = System.Drawing.Color.Blue
        Me.supp_address.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.supp_address.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.supp_address.LineThickness = 4
        Me.supp_address.Location = New System.Drawing.Point(14, 233)
        Me.supp_address.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.supp_address.Name = "supp_address"
        Me.supp_address.Size = New System.Drawing.Size(311, 27)
        Me.supp_address.TabIndex = 3
        Me.supp_address.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnDelete.Location = New System.Drawing.Point(179, 439)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(146, 45)
        Me.btnDelete.TabIndex = 7
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'lblSupp
        '
        Me.lblSupp.AutoSize = True
        Me.lblSupp.BackColor = System.Drawing.Color.Transparent
        Me.lblSupp.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSupp.ForeColor = System.Drawing.Color.Black
        Me.lblSupp.Location = New System.Drawing.Point(12, 39)
        Me.lblSupp.Name = "lblSupp"
        Me.lblSupp.Size = New System.Drawing.Size(31, 21)
        Me.lblSupp.TabIndex = 28
        Me.lblSupp.Text = "ID:"
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnUpdate.Location = New System.Drawing.Point(16, 493)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(146, 45)
        Me.btnUpdate.TabIndex = 6
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'supp_id
        '
        Me.supp_id.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.supp_id.Enabled = False
        Me.supp_id.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.supp_id.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.supp_id.HintForeColor = System.Drawing.Color.Empty
        Me.supp_id.HintText = ""
        Me.supp_id.isPassword = False
        Me.supp_id.LineFocusedColor = System.Drawing.Color.Blue
        Me.supp_id.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.supp_id.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.supp_id.LineThickness = 4
        Me.supp_id.Location = New System.Drawing.Point(16, 65)
        Me.supp_id.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.supp_id.Name = "supp_id"
        Me.supp_id.Size = New System.Drawing.Size(114, 25)
        Me.supp_id.TabIndex = 1
        Me.supp_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'btnInsert
        '
        Me.btnInsert.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnInsert.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInsert.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnInsert.Location = New System.Drawing.Point(14, 439)
        Me.btnInsert.Name = "btnInsert"
        Me.btnInsert.Size = New System.Drawing.Size(146, 45)
        Me.btnInsert.TabIndex = 5
        Me.btnInsert.Text = "Insert"
        Me.btnInsert.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(12, 122)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(127, 21)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "Supplier Name:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(12, 207)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 21)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Address:"
        '
        'dgvSupplier
        '
        Me.dgvSupplier.AllowUserToAddRows = False
        Me.dgvSupplier.AllowUserToDeleteRows = False
        Me.dgvSupplier.AllowUserToResizeColumns = False
        Me.dgvSupplier.AllowUserToResizeRows = False
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.dgvSupplier.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvSupplier.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvSupplier.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.dgvSupplier.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvSupplier.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.MediumSlateBlue
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSupplier.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvSupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSupplier.DoubleBuffered = True
        Me.dgvSupplier.EnableHeadersVisualStyles = False
        Me.dgvSupplier.HeaderBgColor = System.Drawing.Color.MediumSlateBlue
        Me.dgvSupplier.HeaderForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.dgvSupplier.Location = New System.Drawing.Point(355, 89)
        Me.dgvSupplier.Name = "dgvSupplier"
        Me.dgvSupplier.ReadOnly = True
        Me.dgvSupplier.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgvSupplier.RowHeadersVisible = False
        Me.dgvSupplier.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSupplier.Size = New System.Drawing.Size(583, 499)
        Me.dgvSupplier.TabIndex = 9
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(355, 56)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(457, 26)
        Me.txtSearch.TabIndex = 8
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnClear.Location = New System.Drawing.Point(179, 493)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(146, 45)
        Me.btnClear.TabIndex = 36
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'Supplier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(950, 600)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.dgvSupplier)
        Me.Controls.Add(Me.VerticalMenu)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Supplier"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Supplier"
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.VerticalMenu.ResumeLayout(False)
        Me.VerticalMenu.PerformLayout()
        CType(Me.dgvSupplier, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents VerticalMenu As System.Windows.Forms.Panel
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents lblSupp As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents dgvSupplier As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents btnInsert As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents supp_id As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents supp_name As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents supp_address As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents supp_telno As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
End Class
