﻿Imports MySql.Data.MySqlClient
Public Class Inventory
    'VARIABLES
    Dim requestType As String
    Public invMgmt As New Inventory_Mgmt

    'EVENT HANDLERS
    Private Sub Inventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Inventorylist()
        'loadSupplier()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub


    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        requestType = "REPLENISH"
        'setFields(requestType)
        Me.btnInsert.BackColor = Color.MediumSeaGreen

        With invMgmt
            .Text = "Stock Replenishment"
            .process_type = requestType
            .ShowDialog()
        End With
    End Sub

    Private Sub btnCheckOut_Click(sender As Object, e As EventArgs) Handles btnCheckOut.Click
        requestType = "CHECKOUT"
        'setFields(requestType)
        Me.btnCheckOut.BackColor = Color.MediumSeaGreen

        With invMgmt
            .Text = "Stock Checkout"
            .process_type = requestType
            .ShowDialog()
        End With
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Then
                MsgBox("Please enter the item name", vbInformation + vbOKOnly, "System")
                txtSearch.Focus()
            Else
                searchItem(txtSearch.Text)
            End If
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Inventorylist()
    End Sub

    Private Sub btnLoadCritical_Click(sender As Object, e As EventArgs) Handles btnLoadCritical.Click
        Try
            openConnection()

            Dim sql As String
            Dim ds As New DataSet
            sql = "SELECT " _
              & "a.prod_id AS ID," _
              & "a.prod_name AS ProductName," _
              & "(SELECT cat_name FROM category WHERE cat_id = a.cat_id) AS category, " _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "AND is_voided = 0 GROUP BY a.prod_id),0)) + " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "AND is_voided = 1 GROUP BY a.prod_id),0))) AS OnHand " _
              & "FROM products a WHERE a.cat_id NOT IN (5) AND " _
             & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "AND is_voided = 0 GROUP BY a.prod_id),0)) + " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "AND is_voided = 1 GROUP BY a.prod_id),0))) < " & stockLevelCriticalValue(10) _
              & " ORDER BY a.cat_id, a.prod_name"
            '" AND a.cat_id IN (1,2)"
            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(ds, "prod_name")

            dgvInv.DataSource = ds
            dgvInv.DataMember = "prod_name"
            dgvInv.Columns.Item(0).HeaderText = "ID"
            dgvInv.Columns.Item(0).Visible = False
            dgvInv.Columns.Item(1).HeaderText = "Product Name"
            dgvInv.Columns.Item(2).HeaderText = "Category"
            dgvInv.Columns.Item(3).HeaderText = "On Hand"

            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnLoadConsumed_Click(sender As Object, e As EventArgs) Handles btnLoadConsumed.Click
        loadConsumedItems()
    End Sub

    'FUNCTIONS
    Public Sub Inventorylist()
        Try
            openConnection()

            Dim sql As String
            Dim ds As New DataSet
            sql = "SELECT " _
              & "a.prod_id AS ID," _
              & "a.prod_name AS ProductName," _
              & "(SELECT cat_name FROM category WHERE cat_id = a.cat_id) AS category, " _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "AND is_voided = 0 GROUP BY a.prod_id),0)) + " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "AND is_voided = 1 GROUP BY a.prod_id),0))) AS OnHand " _
              & "FROM products a WHERE a.cat_id NOT IN (5) ORDER BY a.cat_id, a.prod_name"
            '"FROM products a WHERE a.cat_id IN (1,2)"


            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(ds, "prod_name")

            dgvInv.DataSource = ds
            dgvInv.DataMember = "prod_name"
            dgvInv.Columns.Item(0).HeaderText = "ID"
            dgvInv.Columns.Item(0).Visible = False
            dgvInv.Columns.Item(1).HeaderText = "Product Name"
            dgvInv.Columns.Item(2).HeaderText = "Category"
            dgvInv.Columns.Item(3).HeaderText = "On Hand"

            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub loadSupplier()
        'cbSupplier.Items.Clear()

        openConnection()

        Dim Query As String
        Dim dtable As New DataTable

        Query = "select * from supplier"
        With COMMAND
            .Connection = MysqlConn
            .CommandText = Query
        End With

        da.SelectCommand = COMMAND
        da.Fill(dtable)

        'If dtable.Rows.Count > 0 Then
        '    cbSupplier.DataSource = dtable
        '    cbSupplier.DisplayMember = "supp_name"
        '    cbSupplier.ValueMember = "supp_id"
        '    cbSupplier.SelectedIndex = -1

        'End If

        closeConnection()
    End Sub

    Sub searchItem(item As String)
        Dim sql As String
        Dim dtable As New DataTable

        sql = "SELECT " _
              & "a.prod_id AS ID," _
              & "a.prod_name AS ProductName," _
              & "(SELECT cat_name FROM category WHERE cat_id = a.cat_id) AS category, " _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "AND is_voided = 0 GROUP BY a.prod_id),0)) + " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "AND is_voided = 1 GROUP BY a.prod_id),0))) AS OnHand " _
              & "FROM products a " _
              & "WHERE a.prod_name LIKE @item AND a.cat_id NOT IN (5) ORDER BY a.prod_id, a.prod_name"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@item", "%" + item + "%")
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)

            If dtable.Rows.Count > 0 Then
                dgvInv.DataSource = dtable
                dgvInv.Columns.Item(0).HeaderText = "ID"
                dgvInv.Columns.Item(0).Visible = False
                dgvInv.Columns.Item(1).HeaderText = "Product Name"
                dgvInv.Columns.Item(2).HeaderText = "Category"
                dgvInv.Columns.Item(3).HeaderText = "On Hand"
            Else
                MsgBox("No record/s found", vbInformation + vbOKOnly, "Result")
                txtSearch.Clear()
                Inventorylist()
            End If


            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)

            COMMAND.Parameters.Clear()
            closeConnection()
        End Try
    End Sub

    Sub loadConsumedItems()
        Try
            openConnection()

            Dim sql As String
            Dim ds As New DataSet
            sql = "(SELECT a.prod_id, a.prod_name, " _
                & "(SELECT cat_name FROM category WHERE cat_id = a.cat_id) AS category, " _
                & "SUM(c.quantity) AS totalConsumed " _
                & "FROM products a " _
                & "INNER JOIN stockhistory c ON c.prod_id = a.prod_id " _
                & "WHERE a.cat_id NOT IN (5) AND c.stock_type = 'CHECKOUT' " _
                & "GROUP BY a.prod_id ORDER BY a.cat_id) " _
                & "UNION ALL " _
                & "(SELECT a.prod_id, a.prod_name, " _
                & "(SELECT cat_name FROM category WHERE cat_id = a.cat_id) AS category, " _
                & "SUM(c.quantity) AS totalConsumed " _
                & "FROM products a " _
                & "INNER JOIN purchaseditems c ON c.prod_id = a.prod_id " _
                & "WHERE a.cat_id IN (1,2) " _
                & "GROUP BY a.prod_id ORDER BY a.cat_id) "

            '" AND a.cat_id IN (1,2)"
            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(ds, "prod_name")

            dgvInv.DataSource = ds
            dgvInv.DataMember = "prod_name"
            dgvInv.Columns.Item(0).HeaderText = "ID"
            dgvInv.Columns.Item(0).Visible = False
            dgvInv.Columns.Item(1).HeaderText = "Product Name"
            dgvInv.Columns.Item(2).HeaderText = "Category"
            dgvInv.Columns.Item(3).HeaderText = "Consumed"

            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class