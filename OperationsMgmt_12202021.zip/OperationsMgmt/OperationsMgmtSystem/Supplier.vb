﻿Imports MySql.Data.MySqlClient
Public Class Supplier

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Supplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Supplist()
        dgvSupplier.ClearSelection()
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        If supp_name.Text = "" Or supp_address.Text = "" Then
            MessageBox.Show("Incomplete Data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf Len(supp_telno.Text) < 7 Or Len(supp_telno.Text) > 11 Then
            MessageBox.Show("Contact number should only have 7-11 characters", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            supp_telno.Focus()
        Else
            Try
                openConnection()
                Dim query As String
                query = "insert into supplier(supp_name, supp_address, supp_telno)values(@name, @address, @telno)"

                With COMMAND
                    .Connection = MysqlConn
                    .CommandText = query
                    .Parameters.AddWithValue("@name", supp_name.Text)
                    .Parameters.AddWithValue("@address", supp_address.Text)
                    .Parameters.AddWithValue("@telno", supp_telno.Text)
                    .ExecuteNonQuery()

                End With
                MessageBox.Show("Supplier Added Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                closeConnection()
                Supplist()
                COMMAND.Parameters.Clear()
            Catch ex As Exception
                MsgBox(ex.Message)
                COMMAND.Parameters.Clear()
            End Try
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If supp_name.Text = "" Or supp_address.Text = "" Then
            MessageBox.Show("Incomplete Data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf Len(supp_telno.Text) < 7 Or Len(supp_telno.Text) > 11 Then
            MessageBox.Show("Contact number should only have 7-11 characters", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            supp_telno.Focus()
        Else
            Try
                openConnection()

                Dim sql = "UPDATE supplier set supp_name= @name, supp_address= @address, supp_telno = @telno where supp_id= @id"

                With COMMAND
                    .Connection = MysqlConn
                    .CommandText = sql
                    .Parameters.AddWithValue("@name", supp_name.Text)
                    .Parameters.AddWithValue("@address", supp_address.Text)
                    .Parameters.AddWithValue("@telno", supp_telno.Text)
                    .Parameters.AddWithValue("@id", supp_id.Text)
                    .ExecuteNonQuery()
                End With

                MessageBox.Show("Update Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                closeConnection()
                Supplist()
                COMMAND.Parameters.Clear()
            Catch ex As Exception
                MsgBox(ex.Message)
                COMMAND.Parameters.Clear()
            End Try

        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If dgvSupplier.Rows.Count = 0 Then
            'Do Nothing
        Else
            If MsgBox("Do you really want to delete this item?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
                Try
                    openConnection()
                    Dim query As String
                    query = " delete from supplier where supp_id= @id"

                    With COMMAND
                        .Connection = MysqlConn
                        .CommandText = query
                        .Parameters.AddWithValue("@id", supp_id.Text)
                        .ExecuteNonQuery()
                    End With


                    MessageBox.Show("Supplier Deleted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    closeConnection()
                    Supplist()
                    COMMAND.Parameters.Clear()
                Catch ex As Exception
                    MsgBox(ex.Message)
                    COMMAND.Parameters.Clear()
                End Try
            End If
        End If
    End Sub

    Private Sub dgvSupplier_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSupplier.CellDoubleClick
        Dim row As DataGridViewRow = dgvSupplier.CurrentRow
        supp_id.Text = row.Cells(0).Value.ToString()
        supp_name.Text = row.Cells(1).Value.ToString()
        supp_address.Text = row.Cells(2).Value.ToString()
        supp_telno.Text = row.Cells(3).Value.ToString()
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Then
                MsgBox("Please enter the supplier name", vbInformation + vbOKOnly, "System")
                txtSearch.Focus()
            Else
                searchSupplier(txtSearch.Text)
            End If
        End If
    End Sub

    Private Sub supp_telno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles supp_telno.KeyPress
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = "." Or Asc(e.KeyChar) = 8 Or e.KeyChar = ControlChars.Back)
    End Sub

    Public Sub Supplist()
        Try
            MysqlConnection()
            Dim sql = "select * from supplier"
            Dim ds As New DataSet

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.Fill(ds)
            closeConnection()
            dgvSupplier.DataSource = ds.Tables(0)
            dgvSupplier.Columns.Item(0).HeaderText = "ID"
            dgvSupplier.Columns.Item(0).Visible = False
            dgvSupplier.Columns.Item(1).HeaderText = "Supplier"
            dgvSupplier.Columns.Item(2).HeaderText = "Address"
            dgvSupplier.Columns.Item(3).HeaderText = "Contact No"
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub searchSupplier(supplier As String)
        Dim sql As String
        Dim dtable As New DataTable

        sql = "select * from supplier WHERE supp_name LIKE @supplier ORDER BY supp_name"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@supplier", "%" + supplier + "%")
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)

            If dtable.Rows.Count > 0 Then
                dgvSupplier.DataSource = dtable
                dgvSupplier.Columns.Item(0).HeaderText = "ID"
                dgvSupplier.Columns.Item(0).Visible = False
                dgvSupplier.Columns.Item(1).HeaderText = "Product Name"
                dgvSupplier.Columns.Item(2).HeaderText = "Category"
                dgvSupplier.Columns.Item(3).HeaderText = "On Hand"
            Else
                MsgBox("No record/s found", vbInformation + vbOKOnly, "Result")
                txtSearch.Clear()
                Supplist()
            End If


            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)

            COMMAND.Parameters.Clear()
            closeConnection()
        End Try
    End Sub

    
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        supp_id.Text = ""
        supp_address.Text = ""
        supp_name.Text = ""
        supp_telno.Text = ""
    End Sub
End Class