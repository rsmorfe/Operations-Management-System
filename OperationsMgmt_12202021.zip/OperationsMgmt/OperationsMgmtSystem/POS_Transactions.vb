﻿Public Class POS_Transactions
    'VARIALBES


    'EVENT HANDLERS
    Private Sub POS_Transactions_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadTransactions()
    End Sub

    Private Sub POS_Transactions_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        resetFields()
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Or Not IsNumeric(txtSearch.Text) Then
                MsgBox("Please enter the correct transaction number", vbInformation + vbOKOnly, "System")
                txtSearch.Focus()
                loadTransactions()
            Else
                searchTransaction(txtSearch.Text)
            End If
        End If
    End Sub


    Private Sub btnVoid_Click(sender As Object, e As EventArgs) Handles btnVoid.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            Dim isVoided As Integer = DataGridView1.CurrentRow.Cells(11).Value
            If isVoided = 0 Then
                Dim a = MsgBox("Void this transaction?", vbQuestion + vbYesNo)
                If a = MsgBoxResult.Yes Then
                    Dim trans_id As Integer = DataGridView1.CurrentRow.Cells(0).Value
                    updateTransaction(trans_id)
                End If
            End If  
        End If
    End Sub

    Private Sub btnloadTransaction_Click(sender As Object, e As EventArgs) Handles btnloadTransaction.Click
        loadTransactions()
    End Sub

    Private Sub btnReprint_Click(sender As Object, e As EventArgs) Handles btnReprint.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            'PRINT RECEIPT FORM
            Dim preview As New ReceiptPreview
            Dim trans_id As Integer = DataGridView1.CurrentRow.Cells(0).Value
            Dim SoldTo As String = DataGridView1.CurrentRow.Cells(7).Value

            preview.strPrint = POS.PrepareTransactionReceipt(trans_id, 2, "", SoldTo)
            'preview.strPrint = PrepareTransactionReceipt(GetLastTransID(CashierID, ReadingID), 1, "", SoldTo)
            preview.ShowDialog()
        End If  
    End Sub

    Private Sub btnVoidTransactions_Click(sender As Object, e As EventArgs) Handles btnVoidTransactions.Click
        loadVoidTransactions()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    'FUNCTIONS
    Sub resetFields()
        txtSearch.Text = ""
        DataGridView1.DataSource = ""
    End Sub

    Sub loadTransactions()
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT * FROM transactionhistory WHERE is_voided = 0 ORDER BY transactionNo DESC"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(publictable)

            If publictable.Rows.Count > 0 Then
                With DataGridView1
                    .DataSource = publictable
                    .Columns(10).Visible = False
                    .Columns(11).Visible = False
                    .AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
                End With
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub loadVoidTransactions()
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT * FROM transactionhistory WHERE is_voided = 1 ORDER BY transactionNo DESC"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(publictable)

            If publictable.Rows.Count > 0 Then
                With DataGridView1
                    .DataSource = publictable
                    .Columns(10).Visible = False
                    .Columns(11).Visible = False
                    .AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
                End With
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub searchTransaction(transaction_id As Integer)
        Dim sql As String
        Dim publictable As New DataTable

        sql = "SELECT * FROM transactionhistory WHERE transactionNo = @trans_id"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@trans_id", transaction_id)
            End With

            da.SelectCommand = COMMAND
            da.Fill(publictable)

            If publictable.Rows.Count > 0 Then
                With DataGridView1
                    .DataSource = publictable
                    .Columns(10).Visible = False
                    .Columns(11).Visible = False
                    .AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
                End With
            Else
                MsgBox("No Record/s found", vbInformation + vbOKOnly, "System")
                txtSearch.Clear()
                txtSearch.Focus()
                loadTransactions()
            End If

            COMMAND.Parameters.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub

    Sub updateTransaction(transaction_id As Integer)
        Try
            openConnection()

            Dim isVoid As Integer = 1
            Dim sql = "UPDATE transactionhistory set is_voided = @void " _
                      & "where transactionNo = @trans_id"
            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@void", isVoid)
                .Parameters.AddWithValue("@trans_id", transaction_id)
                .ExecuteNonQuery()
            End With

            'MessageBox.Show("Updated Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            COMMAND.Parameters.Clear()

            updateTransactionDetails(transaction_id)
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub

    Sub updateTransactionDetails(transaction_id As Integer)
        Try
            openConnection()

            Dim isVoid As Integer = 1
            Dim sql = "UPDATE transactiondetails set is_voided = @void " _
                      & "where transactionNo = @trans_id"
            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@void", isVoid)
                .Parameters.AddWithValue("@trans_id", transaction_id)
                .ExecuteNonQuery()
            End With

            'MessageBox.Show("Updated Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            COMMAND.Parameters.Clear()

            updatePurchasedItems(transaction_id)
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub

    Sub updatePurchasedItems(transaction_id As Integer)
        Try
            openConnection()

            Dim isVoid As Integer = 1
            Dim sql = "UPDATE purchaseditems set is_voided = @void " _
                      & "where transactionNo = @trans_id"
            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@void", isVoid)
                .Parameters.AddWithValue("@trans_id", transaction_id)
                .ExecuteNonQuery()
            End With

            MessageBox.Show("Updated Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            COMMAND.Parameters.Clear()

            loadTransactions()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub


End Class