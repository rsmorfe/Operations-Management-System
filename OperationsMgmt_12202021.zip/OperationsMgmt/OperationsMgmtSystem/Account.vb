﻿Public Class Account

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Account_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadUser(logged_user_id)

        txtLastname.Enabled = False
        txtFirstname.Enabled = False
    End Sub

    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click
        updatePassword(logged_user_id, txtOldPass.Text)
    End Sub

    Sub loadUser(user_id As Integer)
        Dim sql As String
        Dim dtable As New DataTable

        sql = "select FirstName, LastName from users WHERE User_id = @user_id"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@user_id", user_id)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)

            txtFirstname.Text = dtable.Rows(0).Item(0)
            txtLastname.Text = dtable.Rows(0).Item(1)

            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
        

    End Sub

    Sub updatePassword(user_id As Integer, old_pword As String)
        Dim sql As String
        Dim dtable As New DataTable

        sql = "select User_Pass from users WHERE User_id = @user_id"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@user_id", user_id)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)

            COMMAND.Parameters.Clear() 'clear parameters first, to avoid error on next sql command

            If dtable.Rows.Count > 0 Then
                Dim pass As String
                pass = dtable.Rows(0).Item(0)

                If pass.Equals(old_pword) = False Then
                    MsgBox("Enter the correct password", vbExclamation + vbOKOnly, "Incorrect Password")
                    txtOldPass.Clear()
                    txtOldPass.Focus()
                Else
                    If txtNewPass.Text.Equals(txtConfirmPass.Text) = False Then
                        MsgBox("Passwords didn't matched. Kindly re-enter the new password.", vbExclamation + vbOKOnly, "Incorrect Password")
                        txtNewPass.Clear()
                        txtConfirmPass.Clear()
                        txtNewPass.Focus()
                    Else
                        Try
                            openConnection()

                            Dim query = "UPDATE users set User_Pass= @pass where User_id= @id"

                            With COMMAND
                                .Connection = MysqlConn
                                .CommandText = query
                                .Parameters.AddWithValue("@pass", txtNewPass.Text)
                                .Parameters.AddWithValue("@id", logged_user_id)
                                .ExecuteNonQuery()
                            End With

                            MessageBox.Show("Update Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

                            closeConnection()
                            clearFields()
                            loadUser(logged_user_id)

                            COMMAND.Parameters.Clear()
                        Catch ex As Exception
                            MsgBox(ex.Message)
                            COMMAND.Parameters.Clear()
                        End Try
                    End If
                End If
            End If

            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub

    Sub clearFields()
        txtFirstname.Clear()
        txtLastname.Clear()
        txtOldPass.Clear()
        txtNewPass.Clear()
        txtConfirmPass.Clear()
    End Sub
End Class