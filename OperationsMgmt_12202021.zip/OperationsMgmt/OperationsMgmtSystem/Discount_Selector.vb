﻿Public Class Discount_Selector

    Private Sub Discount_Selector_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadDiscounts()
    End Sub

    Private Sub btnApplyDisc_Click(sender As Object, e As EventArgs) Handles btnApplyDisc.Click
        Dim sql As String
        sql = "SELECT disc_value FROM discounts WHERE disc_code = @code"

        Try
            openConnection()

            Dim dt As New DataTable

            With COMMAND
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@code", cbSelectDisc.SelectedValue)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            COMMAND.Parameters.Clear()

            For Each oRow As DataGridViewRow In POS.DataGridView1.Rows

                oRow.Cells("Disc_Code").Value = cbSelectDisc.SelectedValue
                oRow.Cells("Discount").Value = FormatNumber(oRow.Cells("Price").Value * dt.Rows(0).Item("disc_value"), 2)
                oRow.Cells("Price").Value = FormatNumber(oRow.Cells("Price").Value - oRow.Cells("Discount").Value, 2)
            Next
            POS.Compute() 're-compute
            POS.HasAppliedDisc = True

            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub

    Sub loadDiscounts()
        Try
            openConnection()

            Dim sql As String
            Dim table As New DataTable

            sql = "SELECT disc_code ,disc_name FROM discounts WHERE disc_status = 1"

            With COMMAND
                .CommandText = sql
                .Connection = MysqlConn
            End With

            da.SelectCommand = COMMAND
            da.Fill(table)

            With cbSelectDisc
                .DataSource = table
                .DisplayMember = "disc_name"
                .ValueMember = "disc_code"
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    
End Class