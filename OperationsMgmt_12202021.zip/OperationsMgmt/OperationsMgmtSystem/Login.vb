﻿Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class Login
    Dim ctr As Integer = 1 'for login attempts

    Private Sub Button_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        validateLogin("SYSTEM")
    End Sub

    Public Sub validateLogin(mode As String)

        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MessageBox.Show("Please fill the required fields", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Try
                openConnection()
                Dim Query As String
                Dim dTable As New DataTable
                Query = "select User_id,User_Name,User_Pass,User_Level from users where User_Name= @user"

                With COMMAND
                    .Connection = MysqlConn
                    .CommandText = Query
                    .Parameters.AddWithValue("@user", txtUsername.Text)
                    '.Parameters.AddWithValue("@pass", txtPassword.Text)
                End With

                da.SelectCommand = COMMAND
                da.Fill(dTable)

                If dTable.Rows.Count > 0 Then

                    'it gets the data from specific column and assign to the variable
                    Dim user, pass As String
                    user = dTable.Rows(0).Item(1)
                    pass = dTable.Rows(0).Item(2)

                    're-validate user and pass if both are identical
                    If validateInput(user, pass) = True Then

                        MessageBox.Show("Username and Password are correct", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                        saveLoggedUser(dTable.Rows(0).Item(0), dTable.Rows(0).Item(3))
                        setLoginCredentials(logged_user_level)

                        If mode = "SYSTEM" Then
                            Index.Show()
                        ElseIf mode = "POS" Then
                            POS.Show()
                        End If

                        Me.Close()
                    Else
                        MessageBox.Show("Incorrect Username or Password", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("Username doesn't exist", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    txtUsername.Text = ""
                    txtPassword.Text = ""
                End If

                closeConnection()

            Catch ex As Exception
                MessageBox.Show(ex.Message)

            Finally
                'MysqlConn.Dispose()
            End Try

            ctr += 1 'increment login attempt
            COMMAND.Parameters.Clear()

            If ctr > 3 Then
                MessageBox.Show("Max Login Attempts reached", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Stop)
                Application.Exit()
            End If
        End If

    End Sub


    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MysqlConnection() 'Initialize database connection

        Dim ellipseRadius As New Drawing2D.GraphicsPath
        ellipseRadius.StartFigure()
        ellipseRadius.AddArc(New Rectangle(0, 0, 10, 10), 180, 90)
        ellipseRadius.AddLine(10, 0, btnLogin.Width - 20, 0)
        ellipseRadius.AddArc(New Rectangle(btnLogin.Width - 10, 0, 10, 10), -90, 90)
        ellipseRadius.AddLine(btnLogin.Width, 20, btnLogin.Width, btnLogin.Height - 10)
        ellipseRadius.AddArc(New Rectangle(btnLogin.Width - 10, btnLogin.Height - 10, 10, 10), 0, 90)
        ellipseRadius.AddLine(btnLogin.Width - 10, btnLogin.Height, 20, btnLogin.Height)
        ellipseRadius.AddArc(New Rectangle(0, btnLogin.Height - 10, 10, 10), 90, 90)
        ellipseRadius.CloseFigure()
        btnLogin.Region = New Region(ellipseRadius)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        If MsgBox("Do you want to close the program?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
            closeConnection()
            Application.Exit()
        End If
    End Sub


    Private Sub CBshowpass_CheckedChanged(sender As Object, e As EventArgs) Handles CBshowpass.CheckedChanged
        If CBshowpass.Checked Then
            txtPassword.UseSystemPasswordChar = False
        Else
            txtPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Function validateInput(user As String, pass As String)
        Dim result As Boolean = False
        If user.Equals(txtUsername.Text) = True And pass.Equals(txtPassword.Text) = True Then
            result = True
        End If

        Return result
    End Function

    Private Sub TempBtn__POS_Click(sender As Object, e As EventArgs) Handles TempBtn__POS.Click
        validateLogin("POS")
    End Sub
End Class
