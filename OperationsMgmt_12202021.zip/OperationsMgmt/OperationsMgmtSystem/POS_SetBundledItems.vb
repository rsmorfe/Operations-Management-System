﻿Public Class POS_SetBundledItems
    'VARIABLES
    Public refItemIndex As Integer

    'EVENT HANDLERS
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If dgvSelected.Rows.Count = 0 Then
            'Do Nothing
        Else
            dgvSelected.CurrentRow.Cells(3).Value += 1

        End If

    End Sub

    Private Sub btnSubtract_Click(sender As Object, e As EventArgs) Handles btnSubtract.Click
        If dgvSelected.Rows.Count = 0 Then
            'Do Nothing
        ElseIf dgvSelected.CurrentRow.Cells(3).Value = 1 Then
            'Do Nothing
        Else
            dgvSelected.CurrentRow.Cells(3).Value -= 1
        End If
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If dgvSelected.Rows.Count = 0 Then
            'Do Nothing
        Else
            dgvSelected.Rows.Remove(dgvSelected.CurrentRow)
        End If
    End Sub

    Private Sub btnProcess_Click(sender As Object, e As EventArgs) Handles btnProcess.Click
        'POS.pos_ItemsForPuchase = dgvSelected
        For index As Integer = 0 To dgvSelected.RowCount - 1
            POS.pos_ItemsForPuchase.Rows.Add(dgvSelected.Rows(index).Cells("ItemIndex").Value, dgvSelected.Rows(index).Cells("ProdID").Value, dgvSelected.Rows(index).Cells("Item").Value, dgvSelected.Rows(index).Cells("qty").Value)
        Next
        POS.displayForPurchase()
        Me.Close()
    End Sub

    Private Sub dgvItems_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvItems.CellDoubleClick
        Dim row As DataGridViewRow = dgvItems.CurrentRow

        dgvSelected.Rows.Add(refItemIndex, row.Cells(0).Value.ToString(), row.Cells(1).Value.ToString(), 1)
    End Sub

    'FUNCTIONS
    Sub CreateRows()
        With dgvSelected
            .DataSource = Nothing
            .Columns.Clear()
            .ClearSelection()
            .Columns.Add("ItemIndex", "Index")
            .Columns.Item(0).Visible = False
            .Columns.Add("ProdID", "ID")
            .Columns.Add("Item", "Product")
            .Columns.Add("qty", "Qty")
            .AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
        End With
    End Sub

    Sub loadMenus()
        Dim sql As String

        'sql = "SELECT prod_id, prod_name " _
        '      & "FROM products a WHERE item_type = 'SINGLE' AND cat_id NOT IN (1,2,5,6) " _
        '      & "ORDER BY cat_id, prod_name"

        sql = "SELECT prod_id, prod_name, " _
            & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
            & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
            & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
            & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
            & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
            & "GROUP BY a.prod_id),0))) AS OnHand " _
            & "FROM products a WHERE item_type = 'SINGLE' AND cat_id NOT IN (1,2,5,6) AND " _
            & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
            & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
            & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
            & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
            & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
            & "GROUP BY a.prod_id),0))) > 0 " _
            & "ORDER BY cat_id, prod_name"

        Try
            openConnection()

            Dim dt As New DataTable

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            With dgvItems
                .DataSource = dt
                .Columns.Item(0).HeaderText = "ID"
                .Columns.Item(1).HeaderText = "Product Name"
                .Columns.Item(2).HeaderText = "On Hand"
                .Columns.Item(2).Visible = False
                .AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
            End With

            closeConnection()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

  
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        POS.DataGridView1.Rows.Remove(POS.DataGridView1.CurrentRow())
        Me.Close()
    End Sub
End Class