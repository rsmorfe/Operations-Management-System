-- MariaDB dump 10.19  Distrib 10.4.19-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: dbdonbutchi
-- ------------------------------------------------------
-- Server version	10.4.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bundledproducts`
--

DROP TABLE IF EXISTS `bundledproducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundledproducts` (
  `pid_parent` int(11) NOT NULL,
  `pid_child` int(11) NOT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundledproducts`
--

LOCK TABLES `bundledproducts` WRITE;
/*!40000 ALTER TABLE `bundledproducts` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundledproducts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(30) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Direct'),(2,'Indirect'),(3,'Regular'),(4,'Premium'),(5,'Bundled'),(6,'Add-On');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts`
--

DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `disc_code` varchar(10) DEFAULT NULL,
  `disc_name` varchar(20) DEFAULT NULL,
  `disc_value` decimal(13,2) DEFAULT NULL,
  `disc_status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts`
--

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
INSERT INTO `discounts` VALUES ('SC','SENIOR CITIZEN',0.20,1),('PWD','PWD',0.15,1);
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prices`
--

DROP TABLE IF EXISTS `prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prices` (
  `prod_id` int(11) NOT NULL,
  `prod_price` decimal(13,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prices`
--

LOCK TABLES `prices` WRITE;
/*!40000 ALTER TABLE `prices` DISABLE KEYS */;
INSERT INTO `prices` VALUES (37,18.00),(38,18.00),(39,18.00),(50,22.00),(51,22.00),(40,18.00),(41,18.00),(42,18.00),(43,18.00),(44,18.00),(45,18.00),(46,18.00),(47,18.00),(48,18.00),(49,18.00),(54,264.00),(55,132.00),(52,218.00),(53,108.00),(56,240.00),(57,15.00);
/*!40000 ALTER TABLE `prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `prod_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) DEFAULT NULL,
  `prod_name` varchar(30) DEFAULT NULL,
  `prod_desc` varchar(100) DEFAULT NULL,
  `prod_quantity_type` varchar(20) DEFAULT NULL,
  `item_type` varchar(10) DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`prod_id`),
  KEY `cat_id` (`cat_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `category` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,2,'Gas','Petron LPG Gas','pc','SINGLE','2021-07-13 11:48:19'),(2,2,'Plastic Paper','Plastic paper for donuts','box/small','SINGLE','2021-07-13 11:49:10'),(3,2,'Donut Tray(M)','Donut tray medium size','pc','SINGLE','2021-07-13 11:50:21'),(4,2,'Donut Tray(L)','Donut tray large size','pc','SINGLE','2021-07-13 11:50:49'),(5,2,'Donut box(white)','Donut Box','pc','SINGLE','2021-07-13 11:52:47'),(6,1,'Butter','Butter','pack','SINGLE','2021-07-13 11:53:18'),(7,1,'Yeast','yeast','pack','SINGLE','2021-07-13 11:53:53'),(8,1,'Flour','pack size flour','pack','SINGLE','2021-07-13 11:54:11'),(9,1,'Bottled Water','Distilled drinking water','bottle','SINGLE','2021-07-13 11:57:09'),(10,1,'Chocolates','pack size chocolates','pack','SINGLE','2021-07-13 11:57:53'),(11,1,'White Sugar','Refined sugar','pack','SINGLE','2021-07-13 11:58:53'),(12,1,'Candy Sprinkles','pack size candy sprinkles','pack','SINGLE','2021-07-13 11:59:29'),(13,2,'Vegetable Oil','oil for cooking','bottle','SINGLE','2021-07-13 12:00:19'),(14,1,'Peanuts','assorted peanuts','box/small','SINGLE','2021-07-13 12:01:00'),(15,1,'Milk','Condensed Milk','can/small','SINGLE','2021-07-13 12:03:45'),(32,1,'Brown Sugar','Unrefined sugar','pack','SINGLE','2021-11-17 18:29:49'),(33,1,'Sample Product 2','Test Product 2','pc','SINGLE','2021-11-17 18:37:34'),(37,3,'Choco Butternut','Regular - Choco Butternut','pc','SINGLE','2021-11-24 17:31:41'),(38,3,'Choco Ubebe','Regular - Choco Ubebe','pc','SINGLE','2021-11-24 17:32:02'),(39,3,'Choco Crunch','Regular - Choco Crunch','pc','SINGLE','2021-11-24 17:33:38'),(40,3,'Choco Vanilla Glaze','Regular - Choco Vanilla Glaze','pc','SINGLE','2021-11-24 17:33:55'),(41,3,'Choco White Sprinkle','Regular - Choco White Sprinkle','pc','SINGLE','2021-11-24 17:34:09'),(42,3,'Triple Choco','Regular - Triple Choco','pc','SINGLE','2021-11-24 17:34:22'),(43,3,'Yummy Strawberry','Regular - Yummy Strawberry','pc','SINGLE','2021-11-24 17:34:35'),(44,3,'Cheesy Frost','Regular - Cheesy Frost','pc','SINGLE','2021-11-24 17:34:49'),(45,3,'Cake Butternut','Regular - Cake Butternut','pc','SINGLE','2021-11-24 17:35:03'),(46,3,'Cake Vanilla Glaze','Regular - Cake Vanilla Glaze','pc','SINGLE','2021-11-24 17:35:20'),(47,3,'Bavarian Snow','Regular - Bavarian Snow','pc','SINGLE','2021-11-24 17:36:01'),(48,3,'Strawberry Snow','Regular - Strawberry Snow','pc','SINGLE','2021-11-24 17:36:31'),(49,3,'Caramel Snow','Regular - Caramel Snow','pc','SINGLE','2021-11-24 17:36:42'),(50,4,'Boston Bavarian','Premium - Boston Bavarian','pc','SINGLE','2021-11-24 17:36:58'),(51,4,'Boston Strawberry','Premium - Boston Strawberry','pc','SINGLE','2021-11-24 17:37:10'),(52,5,'Regular - One Dozen','Regular - One Dozen','box/large','BUNDLE','2021-11-24 17:40:54'),(53,5,'Regular - Half Dozen','Regular - Half Dozen','box/medium','BUNDLE','2021-11-24 17:46:08'),(54,5,'Premium - One Dozen','Premium - One Dozen','box/large','BUNDLE','2021-11-24 17:46:30'),(55,5,'Premium - Half Dozen','Premium - Half Dozen','box/medium','BUNDLE','2021-11-24 17:46:51'),(56,5,'Mix & Match','Mix & Match','box/large','BUNDLE','2021-11-24 17:47:20'),(57,6,'Mineral Water','Bottled Water','bottle','SINGLE','2021-11-24 18:21:33');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchaseditems`
--

DROP TABLE IF EXISTS `purchaseditems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchaseditems` (
  `transactionNo` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaseditems`
--

LOCK TABLES `purchaseditems` WRITE;
/*!40000 ALTER TABLE `purchaseditems` DISABLE KEYS */;
INSERT INTO `purchaseditems` VALUES (18,41,'Choco White Sprinkle',1),(18,43,'Yummy Strawberry',1),(19,47,'Bavarian Snow',1),(19,45,'Cake Butternut',1),(19,46,'Cake Vanilla Glaze',1),(19,49,'Caramel Snow',1),(19,44,'Cheesy Frost',1),(19,37,'Choco Butternut',1),(20,47,'Bavarian Snow',1),(20,45,'Cake Butternut',1),(20,46,'Cake Vanilla Glaze',1),(20,49,'Caramel Snow',1),(20,44,'Cheesy Frost',1),(20,37,'Choco Butternut',1),(20,47,'Bavarian Snow',1),(20,56,'Mix & Match',1),(21,45,'Cake Butternut',1),(22,44,'Cheesy Frost',1),(22,46,'Cake Vanilla Glaze',1),(22,43,'Yummy Strawberry',1),(23,42,'Triple Choco',1),(24,42,'Triple Choco',1),(24,40,'Choco Vanilla Glaze',1),(24,50,'Boston Bavarian',1),(24,51,'Boston Strawberry',1),(25,39,'Choco Crunch',1),(26,51,'Boston Strawberry',1),(27,38,'Choco Ubebe',1),(27,45,'Cake Butternut',1),(28,47,'Bavarian Snow',2),(28,45,'Cake Butternut',2),(28,44,'Cheesy Frost',2),(29,50,'Boston Bavarian',3),(29,51,'Boston Strawberry',3),(30,45,'Cake Butternut',4),(30,49,'Caramel Snow',2),(30,44,'Cheesy Frost',1),(31,47,'Bavarian Snow',1),(31,45,'Cake Butternut',1),(31,46,'Cake Vanilla Glaze',1),(31,49,'Caramel Snow',1),(31,44,'Cheesy Frost',1),(31,39,'Choco Crunch',1);
/*!40000 ALTER TABLE `purchaseditems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockhistory`
--

DROP TABLE IF EXISTS `stockhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stockhistory` (
  `prod_id` int(11) DEFAULT NULL,
  `product_name` varchar(30) NOT NULL,
  `stock_type` varchar(10) NOT NULL,
  `quantity` int(11) DEFAULT 0,
  `date_created` datetime DEFAULT current_timestamp(),
  `createdby` varchar(50) DEFAULT NULL,
  KEY `prod_id` (`prod_id`) USING BTREE,
  CONSTRAINT `stockhistory_ibfk_1` FOREIGN KEY (`prod_id`) REFERENCES `products` (`prod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockhistory`
--

LOCK TABLES `stockhistory` WRITE;
/*!40000 ALTER TABLE `stockhistory` DISABLE KEYS */;
INSERT INTO `stockhistory` VALUES (47,'Bavarian Snow','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(45,'Cake Butternut','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(46,'Cake Vanilla Glaze','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(49,'Caramel Snow','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(44,'Cheesy Frost','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(37,'Choco Butternut','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(39,'Choco Crunch','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(38,'Choco Ubebe','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(40,'Choco Vanilla Glaze','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(41,'Choco White Sprinkle','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(48,'Strawberry Snow','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(42,'Triple Choco','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(43,'Yummy Strawberry','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(50,'Boston Bavarian','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(51,'Boston Strawberry','REPLENISH',5,'2021-11-24 18:20:32','System Administrator'),(9,'Bottled Water','REPLENISH',5,'2021-11-24 18:22:05','System Administrator'),(57,'Mineral Water','REPLENISH',5,'2021-11-24 18:23:21','System Administrator'),(32,'Brown Sugar','REPLENISH',5,'2021-11-25 06:45:01','System Administrator'),(6,'Butter','REPLENISH',5,'2021-11-25 06:45:01','System Administrator'),(10,'Chocolates','REPLENISH',5,'2021-11-25 06:45:01','System Administrator'),(32,'Brown Sugar','CHECKOUT',3,'2021-11-25 06:45:17','System Administrator'),(6,'Butter','CHECKOUT',3,'2021-11-25 06:45:17','System Administrator'),(10,'Chocolates','CHECKOUT',3,'2021-11-25 06:45:17','System Administrator'),(12,'Candy Sprinkles','REPLENISH',7,'2021-11-25 07:03:32','System Administrator');
/*!40000 ALTER TABLE `stockhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `supp_id` int(11) NOT NULL AUTO_INCREMENT,
  `supp_name` varchar(30) NOT NULL,
  `supp_address` varchar(250) NOT NULL,
  `supp_telno` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`supp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'ABC Merchandise','Poblacion, Muntinlupa City','0987654321'),(3,'XYZ Pharaceuticals','123 Commerce Avenue, Malate, Manila','6237841');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactiondetails`
--

DROP TABLE IF EXISTS `transactiondetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactiondetails` (
  `transactionNo` int(11) NOT NULL,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `prod_id` int(11) DEFAULT NULL,
  `item` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `totalPrice` decimal(12,2) DEFAULT NULL,
  `discCode` varchar(10) DEFAULT NULL,
  `discValue` decimal(13,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactiondetails`
--

LOCK TABLES `transactiondetails` WRITE;
/*!40000 ALTER TABLE `transactiondetails` DISABLE KEYS */;
INSERT INTO `transactiondetails` VALUES (18,'2021-11-24 14:05:42',41,'Choco White Sprinkle',1,18.00,18.00,'',0.00),(18,'2021-11-24 14:05:42',43,'Yummy Strawberry',1,18.00,18.00,'',0.00),(19,'2021-11-24 14:10:25',53,'Regular - Half Dozen',1,108.00,108.00,'',0.00),(20,'2021-11-24 14:12:40',56,'Mix & Match',1,240.00,240.00,'',0.00),(21,'2021-11-24 14:15:21',45,'Cake Butternut',1,18.00,18.00,'',0.00),(22,'2021-11-24 14:17:55',44,'Cheesy Frost',1,18.00,18.00,'',0.00),(22,'2021-11-24 14:17:55',46,'Cake Vanilla Glaze',1,18.00,18.00,'',0.00),(22,'2021-11-24 14:17:55',43,'Yummy Strawberry',1,18.00,18.00,'',0.00),(23,'2021-11-24 14:19:29',42,'Triple Choco',1,18.00,18.00,'',0.00),(24,'2021-11-24 14:21:33',42,'Triple Choco',1,18.00,18.00,'',0.00),(24,'2021-11-24 14:21:33',40,'Choco Vanilla Glaze',1,18.00,18.00,'',0.00),(24,'2021-11-24 14:21:33',50,'Boston Bavarian',1,22.00,22.00,'',0.00),(24,'2021-11-24 14:21:33',51,'Boston Strawberry',1,22.00,22.00,'',0.00),(25,'2021-11-24 14:31:54',39,'Choco Crunch',1,18.00,18.00,'',0.00),(26,'2021-11-24 14:32:52',51,'Boston Strawberry',1,22.00,22.00,'',0.00),(27,'2021-11-25 00:23:02',38,'Choco Ubebe',1,18.00,18.00,'',0.00),(27,'2021-11-25 00:23:02',45,'Cake Butternut',1,18.00,18.00,'',0.00),(28,'2021-11-25 00:34:39',55,'Premium - Half Dozen',1,132.00,132.00,'',0.00),(29,'2021-11-25 01:12:37',55,'Premium - Half Dozen',1,132.00,132.00,'',0.00),(30,'2021-11-25 03:29:27',52,'Regular - One Dozen',1,218.00,174.40,'SC',43.60),(31,'2021-12-04 06:53:22',55,'Premium - Half Dozen',1,132.00,132.00,'',0.00);
/*!40000 ALTER TABLE `transactiondetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactionhistory`
--

DROP TABLE IF EXISTS `transactionhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactionhistory` (
  `transactionNo` int(11) NOT NULL AUTO_INCREMENT,
  `transactionDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `itemsSold` int(11) NOT NULL,
  `totalPrice` decimal(12,2) DEFAULT NULL,
  `Vatable` decimal(12,2) DEFAULT NULL,
  `VAT` decimal(12,2) DEFAULT NULL,
  `Discount` decimal(12,2) DEFAULT NULL,
  `SoldTo` varchar(20) DEFAULT NULL,
  `AmountPaid` decimal(13,2) DEFAULT NULL,
  `ChangeAmount` decimal(13,2) DEFAULT NULL,
  `createdby` int(11) NOT NULL,
  PRIMARY KEY (`transactionNo`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactionhistory`
--

LOCK TABLES `transactionhistory` WRITE;
/*!40000 ALTER TABLE `transactionhistory` DISABLE KEYS */;
INSERT INTO `transactionhistory` VALUES (18,'2021-11-24 14:05:42',2,36.00,32.14,3.86,0.00,'John',40.00,4.00,1),(19,'2021-11-24 14:10:24',1,108.00,96.43,11.57,0.00,'Jane',110.00,2.00,1),(20,'2021-11-24 14:12:40',1,240.00,214.29,25.71,0.00,'',240.00,0.00,1),(21,'2021-11-24 14:15:21',1,18.00,16.07,1.93,0.00,'',18.00,0.00,1),(22,'2021-11-24 14:17:55',3,54.00,48.21,5.79,0.00,'Cho',60.00,6.00,1),(23,'2021-11-24 14:19:29',1,18.00,16.07,1.93,0.00,'',18.00,0.00,1),(24,'2021-11-24 14:21:33',4,80.00,71.43,8.57,0.00,'Mee',100.00,20.00,1),(25,'2021-11-24 14:31:54',1,18.00,16.07,1.93,0.00,'Juana',20.00,2.00,1),(26,'2021-11-24 14:32:52',1,22.00,19.64,2.36,0.00,'Juan',25.00,3.00,1),(27,'2021-11-25 00:23:02',2,36.00,32.14,3.86,0.00,'',36.00,0.00,1),(28,'2021-11-25 00:34:39',1,132.00,117.86,14.14,0.00,'John Patrick',132.00,0.00,1),(29,'2021-11-25 01:12:37',1,132.00,117.86,14.14,0.00,'Joe',150.00,18.00,1),(30,'2021-11-25 03:29:27',1,174.40,155.71,18.69,43.60,'',175.00,0.60,1),(31,'2021-12-04 06:53:22',1,132.00,117.86,14.14,0.00,'Arianne',150.00,18.00,1);
/*!40000 ALTER TABLE `transactionhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `User_id` int(11) NOT NULL AUTO_INCREMENT,
  `LastName` varchar(20) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `User_Name` varchar(15) NOT NULL,
  `User_Pass` varchar(15) NOT NULL,
  `User_Level` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp(),
  `User_Status` int(11) DEFAULT NULL,
  PRIMARY KEY (`User_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','System','admin','admin',1,'2021-04-06 11:29:31',1),(2,'Delos Santos','Dan Joseph','djdelossantos','1234',2,'2021-04-06 11:29:31',1),(3,'Doe','John','johndoe','8888',2,'2021-04-06 11:29:31',0),(4,'User1','Sample','user1','user1234',1,'2021-05-31 21:37:59',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-04 17:03:28
