﻿Imports MySql.Data.MySqlClient
Public Class Products


    'EVENT HANDLERS
    Private Sub Products_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Prodlist()
        dgvProduct.ClearSelection()
        loadCategory()
        loadVariance()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        Dim item_type As String = checkItemType()

        If cbCategory.Text = "" Or prodname.Text = "" Or cbVariance.Text = "" Or proddesc.Text = "" Then
            MessageBox.Show("Incomplete Data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf checkIfExists(prodname.Text) = True Then
            MsgBox("Category name already exists", vbExclamation + vbOKOnly, "Already Exists")
            prodname.Text = ""
            prodname.Focus()
        ElseIf chkBoxSingle.CheckState = CheckState.Unchecked And chkBoxBundle.CheckState = CheckState.Unchecked Then
            MsgBox("Select an Item Type", vbExclamation + vbOKOnly, "Item Type")
        ElseIf chkBoxSingle.CheckState = CheckState.Checked And chkBoxBundle.CheckState = CheckState.Checked Then
            MsgBox("Select only one Item Type", vbExclamation + vbOKOnly, "Item Type")
        Else
            Try
                openConnection()
                Dim query As String
                query = "insert into products (cat_id, prod_name, prod_quantity_type, prod_desc, item_type)" _
                   & "values(@catid,@prod_name,@prod_type,@prod_desc, @item_type)"

                With COMMAND
                    .Connection = MysqlConn
                    .CommandText = query
                    .Parameters.AddWithValue("@catid", cbCategory.SelectedValue)
                    .Parameters.AddWithValue("@prod_name", prodname.Text)
                    .Parameters.AddWithValue("@prod_type", cbVariance.Text)
                    .Parameters.AddWithValue("@prod_desc", proddesc.Text)
                    .Parameters.AddWithValue("@item_type", item_type)
                    .ExecuteNonQuery()
                End With

                MessageBox.Show("Product Added Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                closeConnection()
                clearFields()
                Prodlist()
                loadCategory()
                loadVariance()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            COMMAND.Parameters.Clear()
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim item_type = checkItemType()

        If prodid.Text = "" Or cbCategory.Text = "" Or prodname.Text = "" Or cbVariance.Text = "" Or proddesc.Text = "" Then
            MessageBox.Show("Incomplete Data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf chkBoxSingle.CheckState = CheckState.Unchecked And chkBoxBundle.CheckState = CheckState.Unchecked Then
            MsgBox("Select an Item Type", vbExclamation + vbOKOnly, "Item Type")
        ElseIf chkBoxSingle.CheckState = CheckState.Checked And chkBoxBundle.CheckState = CheckState.Checked Then
            MsgBox("Select only one Item Type", vbExclamation + vbOKOnly, "Item Type")
        Else
            Try
                openConnection()

                Dim sql = "UPDATE products set cat_id = @catid," _
                          & "prod_name = @prod_name," _
                          & "prod_desc = @prod_desc," _
                          & "prod_quantity_type = @prod_type," _
                          & "item_type = @item_type " _
                          & "where prod_id = @prod_id"
                With COMMAND
                    .Connection = MysqlConn
                    .CommandText = sql
                    .Parameters.AddWithValue("@catid", cbCategory.SelectedValue)
                    .Parameters.AddWithValue("@prod_name", prodname.Text)
                    .Parameters.AddWithValue("@prod_type", cbVariance.Text)
                    .Parameters.AddWithValue("@prod_desc", proddesc.Text)
                    .Parameters.AddWithValue("@item_type", item_type)
                    .Parameters.AddWithValue("@prod_id", prodid.Text)
                    .ExecuteNonQuery()
                End With

                MessageBox.Show("Updated Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                closeConnection()
                clearFields()
                Prodlist()
                loadCategory()
                loadVariance()
                COMMAND.Parameters.Clear()
            Catch ex As Exception
                MsgBox(ex.Message)
                COMMAND.Parameters.Clear()
            End Try

        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If dgvProduct.Rows.Count = 0 Then
            'Do Nothing
        Else
            If MsgBox("Do you really want to delete this item?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
                openConnection()
                Dim sql As String
                sql = "delete from products where prod_id = @prodid"

                Try
                    With COMMAND
                        .CommandText = sql
                        .Connection = MysqlConn
                        .Parameters.AddWithValue("@prodid", dgvProduct.CurrentRow.Cells(0).Value)
                        .ExecuteNonQuery()
                    End With

                    MessageBox.Show("Product Deleted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    closeConnection()
                    COMMAND.Parameters.Clear()
                    Prodlist()
                Catch ex As Exception
                    MsgBox(ex.Message)
                    COMMAND.Parameters.Clear()
                End Try

            End If
        End If
    End Sub

    Private Sub dgvProduct_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvProduct.CellDoubleClick
        Dim row As DataGridViewRow = dgvProduct.CurrentRow
        prodid.Text = row.Cells(0).Value.ToString()
        cbCategory.SelectedIndex = cbCategory.FindStringExact(row.Cells(1).Value.ToString())
        prodname.Text = row.Cells(2).Value.ToString()
        cbVariance.SelectedItem = row.Cells(4).Value
        proddesc.Text = row.Cells(3).Value.ToString()

        If row.Cells(5).Value.ToString() = "SINGLE" Then
            chkBoxSingle.CheckState = CheckState.Checked
            chkBoxBundle.CheckState = CheckState.Unchecked
        Else
            chkBoxSingle.CheckState = CheckState.Unchecked
            chkBoxBundle.CheckState = CheckState.Checked
        End If
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Then
                MsgBox("Please enter the product name", vbInformation + vbOKOnly, "System")
                txtSearch.Focus()
            Else
                searchProduct(txtSearch.Text)
            End If
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        clearFields()
        Prodlist()

        loadCategory()
        loadVariance()

        cbCategory.SelectedIndex = -1
        cbVariance.SelectedIndex = -1
    End Sub

    Private Sub txtPOSPrices_Click(sender As Object, e As EventArgs) Handles txtPOSPrices.Click
        Dim prices As New Prices
        prices.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnShowBundled.Click
        If Not prodid.Text = "" Then
            'If chkBoxBundle.CheckState = CheckState.Checked Then
            If dgvProduct.CurrentRow.Cells(5).Value = "BUNDLE" Then
                Dim product_bundle As New Products_BundledItems
                product_bundle.setProdValues(CInt(prodid.Text), prodname.Text)
                product_bundle.ShowDialog()
            End If
        End If
    End Sub

    'FUNCTIONS
    Public Sub Prodlist()
        Try
            openConnection()

            Dim sql As String
            Dim dt As New DataTable
            sql = "SELECT prod_id, cat_name as category, prod_name as Product_Name,prod_desc as Description," _
                & "prod_quantity_type as Variance, item_type FROM PRODUCTS INNER JOIN CATEGORY ON PRODUCTS.cat_id = CATEGORY.cat_id ORDER BY prod_name"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            dgvProduct.DataSource = dt

            dgvProduct.Columns.Item(0).HeaderText = "ID"
            dgvProduct.Columns.Item(0).Visible = False
            dgvProduct.Columns.Item(1).HeaderText = "Category Name"
            dgvProduct.Columns.Item(2).HeaderText = "Product Name"
            dgvProduct.Columns.Item(5).Visible = False
            closeConnection()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub searchProduct(item As String)
        Dim sql As String
        Dim dtable As New DataTable

        sql = "SELECT prod_id, cat_name as category, prod_name as Product_Name,prod_desc as Description," _
                & "prod_quantity_type as Variance, item_type FROM PRODUCTS INNER JOIN CATEGORY ON PRODUCTS.cat_id = CATEGORY.cat_id " _
                & "WHERE prod_name LIKE @item ORDER BY prod_name"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@item", "%" + item + "%")
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)

            If dtable.Rows.Count > 0 Then
                dgvProduct.DataSource = dtable
                dgvProduct.Columns.Item(0).HeaderText = "ID"
                dgvProduct.Columns.Item(0).Visible = False
                dgvProduct.Columns.Item(1).HeaderText = "Category Name"
                dgvProduct.Columns.Item(2).HeaderText = "Product Name"
                dgvProduct.Columns.Item(5).Visible = False
            Else
                MsgBox("No record/s found", vbInformation + vbOKOnly, "Result")
                txtSearch.Clear()
                Prodlist()
            End If


            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)

            COMMAND.Parameters.Clear()
            closeConnection()
        End Try
    End Sub

    Sub loadCategory()
        cbCategory.Items.Clear()

        openConnection()

        Dim Query As String
        Dim dtable As New DataTable

        Query = "select cat_id, cat_name from category"
        With COMMAND
            .Connection = MysqlConn
            .CommandText = Query
        End With

        da.SelectCommand = COMMAND
        da.Fill(dtable)
        'Dim FILENAME As String = "C:\Users\audrey\Documents\log.txt"
        'check if theres a result by getting the count number of rows
        If dtable.Rows.Count > 0 Then
            cbCategory.DataSource = dtable
            cbCategory.DisplayMember = "cat_name"
            cbCategory.ValueMember = "cat_id"
            cbCategory.SelectedIndex = -1

        End If

        closeConnection()
    End Sub

    Sub loadVariance()
        cbVariance.Items.Clear()

        cbVariance.Items.Add("pc")
        cbVariance.Items.Add("pack")
        cbVariance.Items.Add("bottle")
        cbVariance.Items.Add("can/small")
        cbVariance.Items.Add("can/large")
        cbVariance.Items.Add("box/small")
        cbVariance.Items.Add("box/medium")
        cbVariance.Items.Add("box/large")

    End Sub

    Sub clearFields()
        prodid.Text = ""
        prodname.Text = ""
        proddesc.Text = ""
        cbCategory.DataSource = Nothing
        cbVariance.Items.Clear()

        chkBoxSingle.CheckState = CheckState.Unchecked
        chkBoxBundle.CheckState = CheckState.Unchecked
    End Sub

    Function checkItemType()
        Dim result As String

        If chkBoxSingle.CheckState = CheckState.Checked Then
            result = "SINGLE"
        Else
            result = "BUNDLE"
        End If

        Return result
    End Function
    Function checkIfExists(category As String)
        Dim result As Boolean

        Try
            openConnection()

            Dim dt As New DataTable
            Dim sql = "SELECT prod_name FROM PRODUCTS WHERE prod_name = @prodName"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@prodName", category)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            closeConnection()

            If dt.Rows.Count > 0 Then
                result = True
            End If

            dt.Dispose()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        COMMAND.Parameters.Clear()

        Return result
    End Function

End Class