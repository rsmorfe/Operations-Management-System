﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Prices
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.dgvPrices = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.lblSupp = New System.Windows.Forms.Label()
        Me.prodid = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.lblProd = New System.Windows.Forms.Label()
        Me.prodname = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.prodprice = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.btnSetPrice = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        CType(Me.dgvPrices, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlHeader
        '
        Me.pnlHeader.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.pnlHeader.Controls.Add(Me.Label1)
        Me.pnlHeader.Controls.Add(Me.btnExit)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(638, 50)
        Me.pnlHeader.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Linen
        Me.Label1.Location = New System.Drawing.Point(286, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 25)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "PRICES"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnExit.FlatAppearance.BorderSize = 0
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Linen
        Me.btnExit.Location = New System.Drawing.Point(600, 3)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(31, 42)
        Me.btnExit.TabIndex = 18
        Me.btnExit.TabStop = False
        Me.btnExit.Text = "X"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(12, 56)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(224, 26)
        Me.txtSearch.TabIndex = 6
        '
        'dgvPrices
        '
        Me.dgvPrices.AllowUserToAddRows = False
        Me.dgvPrices.AllowUserToDeleteRows = False
        Me.dgvPrices.AllowUserToResizeColumns = False
        Me.dgvPrices.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.dgvPrices.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvPrices.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvPrices.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.dgvPrices.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvPrices.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.MediumSlateBlue
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvPrices.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvPrices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPrices.DoubleBuffered = True
        Me.dgvPrices.EnableHeadersVisualStyles = False
        Me.dgvPrices.HeaderBgColor = System.Drawing.Color.MediumSlateBlue
        Me.dgvPrices.HeaderForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.dgvPrices.Location = New System.Drawing.Point(12, 88)
        Me.dgvPrices.Name = "dgvPrices"
        Me.dgvPrices.ReadOnly = True
        Me.dgvPrices.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvPrices.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvPrices.RowHeadersVisible = False
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgvPrices.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvPrices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvPrices.Size = New System.Drawing.Size(351, 284)
        Me.dgvPrices.TabIndex = 7
        '
        'lblSupp
        '
        Me.lblSupp.AutoSize = True
        Me.lblSupp.BackColor = System.Drawing.Color.Transparent
        Me.lblSupp.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSupp.ForeColor = System.Drawing.Color.Black
        Me.lblSupp.Location = New System.Drawing.Point(380, 88)
        Me.lblSupp.Name = "lblSupp"
        Me.lblSupp.Size = New System.Drawing.Size(31, 21)
        Me.lblSupp.TabIndex = 52
        Me.lblSupp.Text = "ID:"
        '
        'prodid
        '
        Me.prodid.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.prodid.Enabled = False
        Me.prodid.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prodid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.prodid.HintForeColor = System.Drawing.Color.Empty
        Me.prodid.HintText = ""
        Me.prodid.isPassword = False
        Me.prodid.LineFocusedColor = System.Drawing.Color.Blue
        Me.prodid.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.prodid.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.prodid.LineThickness = 4
        Me.prodid.Location = New System.Drawing.Point(384, 114)
        Me.prodid.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.prodid.Name = "prodid"
        Me.prodid.Size = New System.Drawing.Size(125, 27)
        Me.prodid.TabIndex = 51
        Me.prodid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'lblProd
        '
        Me.lblProd.AutoSize = True
        Me.lblProd.BackColor = System.Drawing.Color.Transparent
        Me.lblProd.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProd.ForeColor = System.Drawing.Color.Black
        Me.lblProd.Location = New System.Drawing.Point(380, 158)
        Me.lblProd.Name = "lblProd"
        Me.lblProd.Size = New System.Drawing.Size(128, 21)
        Me.lblProd.TabIndex = 63
        Me.lblProd.Text = "Product Name:"
        '
        'prodname
        '
        Me.prodname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.prodname.Enabled = False
        Me.prodname.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prodname.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.prodname.HintForeColor = System.Drawing.Color.Empty
        Me.prodname.HintText = ""
        Me.prodname.isPassword = False
        Me.prodname.LineFocusedColor = System.Drawing.Color.Blue
        Me.prodname.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.prodname.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.prodname.LineThickness = 4
        Me.prodname.Location = New System.Drawing.Point(384, 184)
        Me.prodname.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.prodname.Name = "prodname"
        Me.prodname.Size = New System.Drawing.Size(229, 27)
        Me.prodname.TabIndex = 62
        Me.prodname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(380, 228)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 21)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "Product Price:"
        '
        'prodprice
        '
        Me.prodprice.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.prodprice.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prodprice.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.prodprice.HintForeColor = System.Drawing.Color.Empty
        Me.prodprice.HintText = ""
        Me.prodprice.isPassword = False
        Me.prodprice.LineFocusedColor = System.Drawing.Color.Blue
        Me.prodprice.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.prodprice.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.prodprice.LineThickness = 4
        Me.prodprice.Location = New System.Drawing.Point(384, 254)
        Me.prodprice.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.prodprice.Name = "prodprice"
        Me.prodprice.Size = New System.Drawing.Size(229, 27)
        Me.prodprice.TabIndex = 64
        Me.prodprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'btnSetPrice
        '
        Me.btnSetPrice.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnSetPrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSetPrice.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSetPrice.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSetPrice.Location = New System.Drawing.Point(497, 333)
        Me.btnSetPrice.Name = "btnSetPrice"
        Me.btnSetPrice.Size = New System.Drawing.Size(116, 39)
        Me.btnSetPrice.TabIndex = 66
        Me.btnSetPrice.Text = "SET PRICE"
        Me.btnSetPrice.UseVisualStyleBackColor = False
        '
        'Prices
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Linen
        Me.ClientSize = New System.Drawing.Size(638, 393)
        Me.Controls.Add(Me.btnSetPrice)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.prodprice)
        Me.Controls.Add(Me.lblProd)
        Me.Controls.Add(Me.prodname)
        Me.Controls.Add(Me.lblSupp)
        Me.Controls.Add(Me.prodid)
        Me.Controls.Add(Me.dgvPrices)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Prices"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Prices"
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        CType(Me.dgvPrices, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents dgvPrices As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents lblSupp As System.Windows.Forms.Label
    Friend WithEvents prodid As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents lblProd As System.Windows.Forms.Label
    Friend WithEvents prodname As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents prodprice As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents btnSetPrice As System.Windows.Forms.Button
End Class
