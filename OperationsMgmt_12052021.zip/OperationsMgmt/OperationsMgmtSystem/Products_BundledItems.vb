﻿Imports MySql.Data.MySqlClient

Public Class Products_BundledItems
    'PUBLIC VARIABLES
    Private prod_id As Integer
    Private prod_name As String

    'EVENT HANDLERS
    Private Sub Products_BundledItems_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        getProdValues()
        Prodlist(Me.prod_id)
        loadBundledProducts(Me.prod_id)
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If dgvSelectedBundles.Rows.Count > 0 Then
            saveBundledList(Me.prod_id)
        Else
            MsgBox("Bundled Item List is empty", vbExclamation + vbOKOnly, "Empty List")
        End If
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Then
                MsgBox("Please enter the product name", vbInformation + vbOKOnly, "System")
                txtSearch.Focus()
            Else
                searchProduct(Trim(txtSearch.Text))
            End If
        End If
    End Sub

    Private Sub dgvProduct_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvProduct.CellDoubleClick
        Dim row As DataGridViewRow = dgvProduct.CurrentRow

        dgvSelectedBundles.Rows.Add(row.Cells(0).Value.ToString(), row.Cells(1).Value.ToString(), 1)
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If dgvSelectedBundles.Rows.Count > 0 Then
            dgvSelectedBundles.Rows.Remove(dgvSelectedBundles.CurrentRow)
        End If
    End Sub

    Private Sub btnAddQty_Click(sender As Object, e As EventArgs) Handles btnAddQty.Click
        If dgvSelectedBundles.Rows.Count = 0 Then
            'Do Nothing
        Else
            dgvSelectedBundles.CurrentRow.Cells(2).Value += 1
        End If
    End Sub

    Private Sub btnSubtractQty_Click(sender As Object, e As EventArgs) Handles btnSubtractQty.Click
        If dgvSelectedBundles.Rows.Count = 0 Then
            'Do Nothing
        ElseIf dgvSelectedBundles.CurrentRow.Cells(2).Value = 1 Then
            'Do Nothing
        Else
            dgvSelectedBundles.CurrentRow.Cells(2).Value -= 1
        End If
    End Sub

    'FUNCTIONS
    Sub setProdValues(id As Integer, item As String)
        prod_id = id
        prod_name = item
    End Sub

    Sub getProdValues()
        txtProd_Id.Text = Me.prod_id
        txtProd_Name.Text = Me.prod_name
    End Sub

    Sub CreateRows()
        dgvSelectedBundles.DataSource = Nothing

        dgvSelectedBundles.Columns.Clear()
        dgvSelectedBundles.ClearSelection()


        dgvSelectedBundles.Columns.Add("ProdID", "ID")
        'dgvSelectedBundles.Columns.Item(0).Width = 25
        dgvSelectedBundles.Columns.Add("Item", "Product")
        'dgvSelectedBundles.Columns.Item(1).Width = 150
        dgvSelectedBundles.Columns.Add("qty", "Qty")
        'dgvSelectedBundles.Columns.Item(2).Width = 25

        dgvSelectedBundles.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)

    End Sub

    Sub loadBundledProducts(id As String)
        dgvSelectedBundles.Refresh()
        Dim parent_id = id

        Try
            openConnection()

            Dim sql As String
            Dim dt As New DataTable
            sql = "SELECT a.pid_child, b.prod_name, a.qty FROM bundledproducts a " _
                & "LEFT JOIN PRODUCTS b ON b.prod_id = a.pid_child " _
                & "WHERE a.pid_parent = @id " _
                & "ORDER BY a.pid_parent, a.pid_child"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@id", parent_id)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            If dt.Rows.Count > 0 Then
                dgvSelectedBundles.DataSource = dt
                dgvSelectedBundles.Columns.Item(0).HeaderText = "ID"
                dgvSelectedBundles.Columns.Item(0).Width = 75
                dgvSelectedBundles.Columns.Item(1).HeaderText = "Product"
                dgvSelectedBundles.Columns.Item(2).HeaderText = "Qty"

                dgvSelectedBundles.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
            Else
                CreateRows()
            End If

            COMMAND.Parameters.Clear()
            closeConnection()

        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try

    End Sub

    Sub Prodlist(id As Integer)
        Try
            openConnection()

            Dim sql As String
            Dim dt As New DataTable
            sql = "SELECT prod_id, prod_name FROM PRODUCTS WHERE prod_id NOT IN(" & id & ") " _
                & "AND cat_id IN(3,4) ORDER BY prod_name"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            dgvProduct.DataSource = dt
            dgvProduct.Columns.Item(0).HeaderText = "ID"
            dgvProduct.Columns.Item(0).Width = 75
            dgvProduct.Columns.Item(1).HeaderText = "Product"
            closeConnection()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub searchProduct(item As String)
        Try
            Dim sql As String
            Dim dtable As New DataTable

            Dim product = "%" + item + "%"
            sql = "SELECT prod_id, prod_name FROM PRODUCTS WHERE prod_name LIKE @item " _
                & "AND prod_id NOT IN(@id) AND cat_id IN(3,4)"
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = Sql
                .Parameters.AddWithValue("@item", product)
                .Parameters.AddWithValue("@id", Me.prod_id)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)

            If dtable.Rows.Count > 0 Then
                dgvProduct.DataSource = dtable
                dgvProduct.Columns.Item(0).HeaderText = "ID"
                dgvProduct.Columns.Item(0).Width = 75
                dgvProduct.Columns.Item(1).HeaderText = "Product Name"
            Else
                MsgBox("No record/s found", vbInformation + vbOKOnly, "Result")
                txtSearch.Clear()
                Prodlist(prod_id)
            End If


            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)

            COMMAND.Parameters.Clear()
            closeConnection()
        End Try
    End Sub

    Sub saveBundledList(id As Integer)
        Dim parent_id = id
        Dim result As Integer

        'DELETE CURRENT BUNDLED PRODUTS BY ITS PARENT ID
        deleteBundledProductsByParentId(parent_id)

        'STORE THE NEW BUNDLED PRODUCTS
        Try
            'we open Connection
            openConnection()

            For Each BundledProduct As DataGridViewRow In dgvSelectedBundles.Rows
                '-----------------
                'TESTING CODE ONLY
                'DISPLAY ID OF BOTH Parent Product and Bundled Products, and Quantity
                'value = parent_id & "," & BundledProduct.Cells(0).Value & "," & BundledProduct.Cells(1).Value
                'Console.WriteLine(value)
                '-----------------

                With COMMAND
                    .Connection = MysqlConn
                    .CommandText = "INSERT INTO bundledproducts" _
                        & "(pid_parent, pid_child, qty) VALUES(@parent_id,@child_id,@qty)"

                    .Parameters.AddWithValue("@parent_id", parent_id)
                    .Parameters.AddWithValue("@child_id", BundledProduct.Cells(0).Value)
                    .Parameters.AddWithValue("@qty", BundledProduct.Cells(2).Value)

                    'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                    result = COMMAND.ExecuteNonQuery
                    'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                    If result = 0 Then
                        MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                        COMMAND.Parameters.Clear()
                        Exit Sub
                    End If
                End With

                COMMAND.Parameters.Clear()
            Next

            MsgBox("Successfully Saved", vbOKOnly + vbInformation, "System")

            dgvSelectedBundles.Columns.Clear()
            loadBundledProducts(Me.prod_id)
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try

    End Sub

    Sub deleteBundledProductsByParentId(id As Integer)
        Dim parent_id = id

        Try
            'we open Connection
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = "DELETE FROM bundledproducts WHERE pid_parent = @parent_id"
                .Parameters.AddWithValue("@parent_id", parent_id)
                .ExecuteNonQuery()
            End With

            COMMAND.Parameters.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Dim a = MsgBox("Are you sure? This will remove all tagged products for this bundle", vbQuestion + vbYesNo)
        If a = MsgBoxResult.Yes Then
            deleteBundledProductsByParentId(Me.prod_id)
            CreateRows()
        End If
    End Sub

End Class