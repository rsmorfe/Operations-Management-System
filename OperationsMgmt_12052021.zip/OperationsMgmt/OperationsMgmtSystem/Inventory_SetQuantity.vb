﻿Public Class Inventory_SetQuantity
    'VARIABLES
    Public process_type As String
    Public setValueType As Integer
    Private prod_id As Integer
    Private prod_name As String
    Private prod_qty As Integer

    'EVENT HANDLERS
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Dispose()
    End Sub

    Private Sub btnAddToList_Click(sender As Object, e As EventArgs) Handles btnAddToList.Click
        'MsgBox(computeMetricValue(Me.process_type, txtMetricValue.Text, txtQty.Text))
        If chkbox_Standard.CheckState = CheckState.Unchecked And chkbox_Metric.CheckState = CheckState.Unchecked Then
            MsgBox("Select Input Type", vbInformation + vbOKOnly, "System")
        ElseIf txtQty.Text = "" Then
            MsgBox("Enter Quantity", vbInformation + vbOKOnly, "System")
        Else
            validateInput(Me.process_type, CInt(txtQty.Text))
        End If

    End Sub

    Private Sub txtQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                         Asc(e.KeyChar) = 8)
    End Sub


    Private Sub chkbox_Metric_CheckStateChanged(sender As Object, e As EventArgs) Handles chkbox_Metric.CheckStateChanged
        setValueType = 2 ' FOR METRIC

        If chkbox_Metric.Checked = True Then
            chkbox_Standard.CheckState = CheckState.Unchecked
            txtMetricValue.Enabled = True
        Else
            chkbox_Metric.CheckState = CheckState.Unchecked
            txtMetricValue.Enabled = False
        End If
    End Sub

    Private Sub chkbox_Standard_CheckStateChanged(sender As Object, e As EventArgs) Handles chkbox_Standard.CheckStateChanged
        setValueType = 1 ' FOR STANDARD

        If chkbox_Metric.Checked = True Then
            chkbox_Metric.CheckState = CheckState.Unchecked
            txtMetricValue.Enabled = False
        End If
    End Sub

    Private Sub txtMetricValue_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMetricValue.KeyPress
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                 Asc(e.KeyChar) = 8)
    End Sub


    'FUNCTIONS
    Public Sub setValues(process As String, id As Integer, name As String, qty As Integer)
        process_type = process
        Me.prod_id = id
        Me.prod_name = name
        Me.prod_qty = qty
    End Sub

    Function computeMetricValue(process As String, metricValue As Double, qty As Integer)
        Return qty / metricValue
    End Function

    Sub validateInput(process As String, num As Double)
        If num <= 0 Then
            MsgBox("Enter valid quantity", vbInformation + vbOKOnly, "Incorrect Input")
            With txtQty
                .Clear()
                .Focus()
            End With
        Else
            'IF USING METRIC CONVERSION
            If setValueType = 2 Then
                num = computeMetricValue(Me.process_type, txtMetricValue.Text, num)
            End If

            If process = "REPLENISH" Then
                addToList(Me.prod_id, Me.prod_name, num)
            ElseIf process = "CHECKOUT" Then
                If num > Me.prod_qty Then
                    MsgBox("Entered quantity is higher than available stock", vbInformation + vbOKOnly, "Incorrect Input")
                    With txtQty
                        .Clear()
                        .Focus()
                    End With
                Else
                    addToList(Me.prod_id, Me.prod_name, num)
                End If
            End If
        End If
    End Sub
    Sub addToList(id As Integer, name As String, qty As Double)
        Index.InventoryForm.invMgmt.dgvSelectedItems.Rows.Add(id, name, qty)
        Me.Close()
    End Sub

End Class