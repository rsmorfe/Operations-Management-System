﻿Public Class POS
    'VARIABLE
    Public table As New DataTable 'for handling data for setting up EventHandler on Items
    Public pos_table As New DataTable 'for handling data for setting up EventHandler on Categories
    Public pos_ItemsForPuchase As New DataGridView 'for handling single/bundled items
    Public HasAppliedDisc As Boolean

    'EVENT HANDLERS
    Private Sub POS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MysqlConnection() 'Initialize database connection
        CreateRows()
        CreateForPurchaseRows()
        LoadPOSCategories()
    End Sub

    Private Sub POS_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim a = MsgBox("Close the system?", vbQuestion + vbYesNo)
        If a = MsgBoxResult.Yes Then
            e.Cancel = False
            Login.Show()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If DataGridView1.Rows.Count > 0 Then
            Dim a = MsgBox("Cancel Transaction?", vbQuestion + vbYesNo)
            If a = MsgBoxResult.Yes Then
                'CLEAR FlowLayoutPanel Controls
                If FlowLayoutPanel1.Controls.Count > 0 Then
                    Dim cnt As Integer = FlowLayoutPanel1.Controls.Count - 1
                    While FlowLayoutPanel1.Controls.Count > 0
                        FlowLayoutPanel1.Controls(cnt).Dispose()
                        cnt -= 1
                    End While
                End If

                DataGridView1.Columns.Clear()
                CreateRows()
                CreateForPurchaseRows()
                resetFields()
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If DataGridView1.Rows.Count > 0 Then
            Dim checkout As New POS_CheckoutSummary
            With checkout
                .TotalItems = CInt(txtTotalItems.Text)
                .TotalAmount = CDbl(txtTotalPrice.Text)
                .TotalVatable = CDbl(txtVatable.Text)
                .TotalVat = CDbl(txtVat.Text)
                .totalDiscount = CDbl(txtDiscount.Text)
                .LoadSubtotal()
                .TextBox1.Focus()
            End With
            checkout.ShowDialog()

            'CreateTransactionHeader(False, CInt(txtTotalItems.Text), CDbl(txtTotalPrice.Text), CDbl(txtVatable.Text), CDbl(txtVat.Text), LoggedUserID, ReadingID)
        Else
            'MsgBox("no items in transaction list!", vbExclamation + vbOKOnly, "No items")
            'Do Nothing
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If DataGridView1.Rows.Count = 0 Then
            'Do Nothing
        Else
            If DataGridView1.CurrentRow.Cells(3).Value < DataGridView1.CurrentRow.Cells(7).Value Then
                DataGridView1.CurrentRow.Cells(3).Value += 1
                DataGridView1.CurrentRow.Cells(6).Value = FormatNumber(CInt(DataGridView1.CurrentRow.Cells(2).Value) * CInt(DataGridView1.CurrentRow.Cells(3).Value), 2)
                Compute()
            End If
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If DataGridView1.Rows.Count = 0 Then
            'Do Nothing
        ElseIf DataGridView1.CurrentRow.Cells(3).Value = 1 Then
            'Do Nothing
        Else
            DataGridView1.CurrentRow.Cells(3).Value -= 1
            DataGridView1.CurrentRow.Cells(6).Value = FormatNumber(CInt(DataGridView1.CurrentRow.Cells(2).Value) * CInt(DataGridView1.CurrentRow.Cells(3).Value), 2)

            Compute()
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If DataGridView1.Rows.Count = 0 Then
            'nothing
        Else
            Dim a = MsgBox("Remove the selected item?", vbQuestion + vbYesNo)
            If a = MsgBoxResult.Yes Then
                DeleteForPurchase(DataGridView1.CurrentRow.Cells(0).Value)
                DataGridView1.Rows.Remove(DataGridView1.CurrentRow())
                Compute()
            End If
        End If
    End Sub

    Private Sub btnApplyDisc_Click(sender As Object, e As EventArgs) Handles btnApplyDisc.Click
        If DataGridView1.Rows.Count = 0 Then
            'do nothing
        Else
            'If DataGridView1.CurrentRow.Cells("Disc_Code").Value <> String.Empty Then
            If HasAppliedDisc = True Then
                MsgBox("Remove the applied discount before applying a new discount", vbExclamation + vbOKOnly, "System")
            Else
                Dim DiscSelect As New Discount_Selector
                DiscSelect.ShowDialog()
            End If
        End If
    End Sub

    Private Sub btnRemoveDisc_Click(sender As Object, e As EventArgs) Handles btnRemoveDisc.Click
        If DataGridView1.Rows.Count = 0 Then
            'do nothing
        Else
            If HasAppliedDisc = True Then
                If MsgBox("Remove applied discount to all items?", vbQuestion + vbYesNo, "System") = MsgBoxResult.Yes Then
                    For Each oRow As DataGridViewRow In DataGridView1.Rows
                        oRow.Cells("Price").Value = FormatNumber(oRow.Cells("OriginalPrice").Value * oRow.Cells("Qty").Value, 2)
                        oRow.Cells("Disc_Code").Value = ""
                        oRow.Cells("Discount").Value = FormatNumber(0.0, 2)
                    Next
                    Compute() 're-compute
                    HasAppliedDisc = False
                Else
                    'Do Nothing
                End If
            End If
        End If
    End Sub

    'FUNCTIONS
    Sub CreateRows()
        DataGridView1.Columns.Add("ProdID", "ID")
        DataGridView1.Columns(0).Width = 125
        DataGridView1.Columns(0).Visible = True
        DataGridView1.Columns.Add("Item", "Product")
        DataGridView1.Columns(1).Width = 280
        DataGridView1.Columns(1).Visible = True
        DataGridView1.Columns.Add("OriginalPrice", "Price")
        DataGridView1.Columns(2).Width = 125
        DataGridView1.Columns(2).Visible = True
        DataGridView1.Columns.Item(2).DefaultCellStyle.Format = "####.#0"
        DataGridView1.Columns.Add("Qty", "Quantity")
        DataGridView1.Columns(3).Width = 125
        DataGridView1.Columns(3).Visible = True
        DataGridView1.Columns.Add("Disc_Code", "CODE")
        DataGridView1.Columns(4).Width = 125
        DataGridView1.Columns(4).Visible = True
        DataGridView1.Columns.Add("Discount", "Discount")
        DataGridView1.Columns(5).Width = 125
        DataGridView1.Columns.Item(5).DefaultCellStyle.Format = "####.#0"
        DataGridView1.Columns(5).Visible = True
        DataGridView1.Columns.Add("Price", "Total Price")
        DataGridView1.Columns(6).Width = 125
        DataGridView1.Columns.Item(6).DefaultCellStyle.Format = "####.#0"
        DataGridView1.Columns(6).Visible = True
        DataGridView1.Columns.Add("Stock", "Available")
        DataGridView1.Columns(7).Width = 125
        DataGridView1.Columns(7).Visible = False
        DataGridView1.Columns.Add("Item_type", "Type")
        DataGridView1.Columns(8).Width = 125
        DataGridView1.Columns(8).Visible = False
    End Sub

    Sub CreateForPurchaseRows()
        'TO ACCEPT SINGLE AND BUNDLE ITEMS
        pos_ItemsForPuchase.DataSource = Nothing
        pos_ItemsForPuchase.Columns.Clear()
        pos_ItemsForPuchase.Rows.Clear()
        pos_ItemsForPuchase.Columns.Add("RefIndex", "Index")
        pos_ItemsForPuchase.Columns.Add("Prod_id", "ID")
        pos_ItemsForPuchase.Columns.Add("Prod_name", "Name")
        pos_ItemsForPuchase.Columns.Add("Qty", "Quantity")
    End Sub

    Sub LoadButtons(catType As Integer)
        'CLEAR FlowLayoutPanel Controls
        If FlowLayoutPanel1.Controls.Count > 0 Then
            Dim cnt As Integer = FlowLayoutPanel1.Controls.Count - 1
            While FlowLayoutPanel1.Controls.Count > 0
                FlowLayoutPanel1.Controls(cnt).Dispose()
                cnt -= 1
            End While
        End If

        Dim publictable As New DataTable
        Dim sql As String

        'ORIGINAL CODE
        'sql = "SELECT a.prod_id, a.prod_name, b.prod_price," _
        '    & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
        '    & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
        '    & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
        '    & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
        '    & "(COALESCE((SELECT SUM(quantity) FROM transactiondetails d WHERE d.prod_id = a.prod_id " _
        '    & "GROUP BY a.prod_id),0))) AS OnHand, a.item_type " _
        '    & "FROM products a LEFT JOIN prices b ON a.prod_id = b.prod_id " _
        '    & "WHERE a.cat_id = @cat AND " _
        '   & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
        '    & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
        '    & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
        '    & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
        '    & "(COALESCE((SELECT SUM(quantity) FROM transactiondetails d WHERE d.prod_id = a.prod_id " _
        '    & "GROUP BY a.prod_id),0))) > 0 " _
        '    & "ORDER BY a.cat_id, OnHand DESC"

        'REVISED CODE
        sql = "SELECT a.prod_id, a.prod_name, b.prod_price," _
            & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
            & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
            & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
            & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
            & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
            & "GROUP BY a.prod_id),0))) AS OnHand, a.item_type " _
            & "FROM products a LEFT JOIN prices b ON a.prod_id = b.prod_id " _
            & "WHERE a.cat_id = @cat " _
            & "ORDER BY a.cat_id, OnHand DESC"

        With COMMAND
            .CommandText = sql
            .Connection = MysqlConn
            .Parameters.AddWithValue("@cat", catType)
        End With

        With da
            .SelectCommand = COMMAND
            .Fill(publictable)
            .Fill(table) 'used for setting up AddHandler with Call Function
        End With

        COMMAND.Parameters.Clear()

        If table.Rows.Count > 0 Then
            For i As Integer = 0 To publictable.Rows.Count - 1
                If publictable.Rows(i).Item("OnHand") > 0 Or publictable.Rows(i).Item("item_type") = "BUNDLE" Then
                    Dim b As Button = New Button() 'Create new button

                    'set button properties
                    'Console.WriteLine(publictable.Rows(i).Item("prod_name").ToString)
                    b.Name = "Button" + (i + 1).ToString
                    b.Text = publictable.Rows(i).Item("prod_name").ToString
                    b.ForeColor = SystemColors.ControlText
                    'b.BackColor = Color.FromArgb(255, 255, 192)
                    b.BackColor = Color.MediumSeaGreen
                    b.Font = New Font("Century Gothic", 12, FontStyle.Bold)
                    b.Width = 175
                    b.Height = 110
                    b.TextAlign = ContentAlignment.MiddleCenter
                    b.Margin = New Padding(6)

                    'add button to FlowLayoutPanel
                    FlowLayoutPanel1.Controls.Add(b)

                    'add Handler (EventHandler)
                    AddHandler b.Click, AddressOf ButtonClick
                End If          
            Next
            FlowLayoutPanel1.FlowDirection = FlowLayoutPanel1.FlowDirection 'refresh FlowLayoutPanel
        End If

    End Sub

    'For creating EventHandler on generated buttons
    Private Sub ButtonClick(sender As Object, e As EventArgs)
        Dim btn As Button = DirectCast(sender, Button)

        Dim dr() As System.Data.DataRow 'Array
        dr = table.Select("prod_name='" & btn.Text & "'") 'get data form table, them search for specific Product Name
        If dr.Length > 0 Then
            'Array(Selected Record) = Array(ProdID),Array(ProdName),Array(Price)

            'AddToList(dr(0)("prod_id").ToString, dr(0)("prod_name").ToString, FormatNumber(CDbl(dr(0)("price").ToString), 2))
            AddToList(dr(0)("prod_id").ToString, dr(0)("prod_name").ToString, FormatNumber(CDbl(dr(0)("prod_price")), 2), dr(0)("OnHand").ToString, dr(0)("item_type").ToString)

            'FOR BUNDLE ITEMS ONLY
            Dim index As Integer = DataGridView1.Rows.Count - 1
            Dim refProdId As Integer = DataGridView1.Rows(index).Cells(0).Value
            If dr(0)("item_type") = "BUNDLE" Then
                With POS_SetBundledItems
                    .refItemIndex = refProdId
                    '.Text = refProdId
                    .CreateRows()
                    .loadMenus()
                    .ShowDialog()
                End With
            End If
        End If

    End Sub

    Sub LoadPOSCategories()
        'CLEAR FlowLayoutPanel Controls
        If FlowLayoutPanel3.Controls.Count > 0 Then
            Dim cnt As Integer = FlowLayoutPanel3.Controls.Count - 1
            While FlowLayoutPanel3.Controls.Count > 0
                FlowLayoutPanel3.Controls(cnt).Dispose()
                cnt -= 1
            End While
        End If

        Dim publictable As New DataTable
        Dim sql As String


        sql = "SELECT cat_id, cat_name FROM category " _
            & "WHERE cat_id NOT IN(1,2)"

        With COMMAND
            .CommandText = sql
            .Connection = MysqlConn
        End With

        With da
            .SelectCommand = COMMAND
            .Fill(publictable)
            .Fill(pos_table) 'used for setting up AddHandler with Call Function
        End With


        If pos_table.Rows.Count > 0 Then
            For i As Integer = 0 To publictable.Rows.Count - 1
                Dim b As Button = New Button() 'Create new button

                'set button properties
                ' Console.WriteLine(publictable.Rows(i).Item("prod_name").ToString)
                b.Name = "Button" + (i + 1).ToString
                b.Text = publictable.Rows(i).Item("cat_name").ToString
                b.ForeColor = SystemColors.ControlText
                'b.BackColor = Color.FromArgb(255, 255, 192)
                b.BackColor = Color.Moccasin
                b.Font = New Font("Century Gothic", 12, FontStyle.Bold)
                b.Width = 130
                b.Height = 75
                b.TextAlign = ContentAlignment.MiddleCenter
                b.Margin = New Padding(6)

                'add button to FlowLayoutPanel
                FlowLayoutPanel3.Controls.Add(b)

                'add Handler (EventHandler)
                AddHandler b.Click, AddressOf CategoryClick
            Next
            FlowLayoutPanel3.FlowDirection = FlowLayoutPanel3.FlowDirection 'refresh FlowLayoutPane3
        End If
    End Sub

    'For creating EventHandler on generated buttons
    Private Sub CategoryClick(sender As Object, e As EventArgs)
        Dim btn As Button = DirectCast(sender, Button)

        Dim dr() As System.Data.DataRow 'Array
        dr = pos_table.Select("cat_name='" & btn.Text & "'") 'get data form table, them search for specific Product Name
        If dr.Length > 0 Then
            LoadButtons(dr(0)("cat_id").ToString)
        End If
    End Sub

    Sub Compute()
        Dim totalitems As Integer = 0
        Dim totalamt As Double = 0.0
        Dim totaldisc As Double = 0.0

        If DataGridView1.RowCount > 0 Then

            For index As Integer = 0 To DataGridView1.RowCount - 1
                totalitems += CInt(DataGridView1.Rows(index).Cells(3).Value)
                totalamt += FormatNumber(DataGridView1.Rows(index).Cells(6).Value, 2)
                totaldisc += FormatNumber(DataGridView1.Rows(index).Cells(5).Value, 2)
            Next
        End If

        txtTotalItems.Text = totalitems
        'totalamt = totalamt - totaldisc 'DISCOUNTED PRICE
        'txtTotalPrice.Text = FormatNumber(totalamt, 2)
        txtTotalPrice.Text = FormatNumber(Decimal.Round(CDec(totalamt), 2), 2)
        'txtVatable.Text = FormatNumber(totalamt / Vatable, 2)
        txtVatable.Text = Decimal.Round(CDec(totalamt) / CDec(Vatable), 2)
        'txtVat.Text = FormatNumber(FormatNumber(totalamt / Vatable, 2) * VAT, 2)
        txtVat.Text = Decimal.Round(CDec(txtVatable.Text) * CDec(VAT), 2)
        'txtDiscount.Text = FormatNumber(totaldisc, 2)
        txtDiscount.Text = FormatNumber(Decimal.Round(CDec(totaldisc), 2), 2)
    End Sub

    Sub resetFields()
        txtTotalItems.Text = 0
        txtTotalPrice.Text = FormatNumber(0, 2)
        txtVatable.Text = FormatNumber(0, 2)
        txtVat.Text = FormatNumber(0, 2)
        txtDiscount.Text = FormatNumber(0, 2)
    End Sub

    Public Sub AddToList(prodID As Integer, item As String, price As Double, stock As Integer, type As String)

        Dim Prodname As String
        Dim qty As Integer = 1
        Dim ProdPrice As Double 'price * qty

        Prodname = item
        ProdPrice = qty * price

        Dim RecordFound As Boolean = False

        For Each oRow As DataGridViewRow In DataGridView1.Rows
            Dim oPRoductCell As DataGridViewCell = oRow.Cells(1)
            Dim rowIndex = DataGridView1.Rows.Count - 1
            If oPRoductCell.Value = Prodname Then

                If oRow.Cells(3).Value < oRow.Cells(7).Value Then
                    oRow.Cells(3).Value += qty
                    oRow.Cells(6).Value = oRow.Cells(2).Value * oRow.Cells(3).Value

                End If

                RecordFound = True
                Me.Focus()

                'Set last record as selected
                DataGridView1.CurrentCell = DataGridView1(0, rowIndex)
                DataGridView1.Refresh()
            End If
        Next

        If RecordFound = False Then
            Dim rowIndex = DataGridView1.Rows.Count
            DataGridView1.Rows.Add(prodID, Prodname, price, qty, "", FormatNumber(0, 2), qty * price, stock, type)
            Me.Focus()

            If rowIndex > 0 Then
                'Set last record as selected
                DataGridView1.CurrentCell = DataGridView1(0, rowIndex)
                DataGridView1.Refresh()
            End If


        End If
        'End If
        Compute()
    End Sub

    Public Function GetLastTransID()
        Dim sql As String
        Dim publictable As New DataTable

        'sql = "SELECT MAX(TransID) FROM transactionheader WHERE UserID = @uid AND CReadingID = @crid"
        sql = "SELECT MAX(transactionNo) FROM transactionhistory"

        With COMMAND
            .Connection = MysqlConn
            .CommandText = sql
            '.Parameters.AddWithValue("@uid", cid)
            '.Parameters.AddWithValue("@crid", crid)
        End With

        da.SelectCommand = COMMAND
        da.Fill(publictable)

        COMMAND.Parameters.Clear()
        Return publictable.Rows(0).Item(0)
    End Function

    Sub CreateTransactionHeader(totalItems As Integer, totalprice As Double, vatable As Double, vat As Double, discount As Double, SoldTo As String, AmountPaid As Double, ChangeAmt As Double, user_id As Integer)
        Dim result As Integer

        Try
            'we open Connection
            openConnection()
            'Dim cat_index As Integer = ComboBox1.SelectedIndex
            With COMMAND
                .Connection = MysqlConn
                .CommandText = "INSERT INTO transactionhistory" _
                    & "(itemsSold, totalPrice ,Vatable , VAT, Discount, SoldTo, AmountPaid, ChangeAmount, createdby) " _
                    & "VALUES(@itemsSold,@totalPrice,@Vatable,@VAT,@Discount,@SoldTo,@AmountPd,@ChangeAmt,@createdby)"

                .Parameters.AddWithValue("@itemsSold", totalItems)
                .Parameters.AddWithValue("@totalPrice", FormatNumber(totalprice, 2))
                .Parameters.AddWithValue("@Vatable", FormatNumber(vatable, 2))
                .Parameters.AddWithValue("@VAT", FormatNumber(vat, 2))
                .Parameters.AddWithValue("@Discount", FormatNumber(discount, 2))
                .Parameters.AddWithValue("@SoldTo", If(SoldTo, DBNull.Value))
                .Parameters.AddWithValue("@AmountPd", FormatNumber(AmountPaid, 2))
                .Parameters.AddWithValue("@ChangeAmt", FormatNumber(ChangeAmt, 2))
                .Parameters.AddWithValue("@createdby", user_id)
                '.Parameters.AddWithValue("@crid", crid)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = COMMAND.ExecuteNonQuery
                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                Else
                    COMMAND.Parameters.Clear()
                    CreateTransactionDetails(GetLastTransID(), SoldTo)
                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Sub CreateTransactionDetails(transID As Integer, SoldTo As String)
        Dim result As Integer

        Try
            'we open Connection
            'MysqlConn.Open()
            'Dim cat_index As Integer = ComboBox1.SelectedIndex
            For Each ProductInList As DataGridViewRow In DataGridView1.Rows
                With COMMAND
                    .Connection = MysqlConn
                    .CommandText = "INSERT INTO transactiondetails" _
                        & "(transactionNo,prod_id,item,quantity,price,totalprice,discCode,discValue) " _
                        & "VALUES(@TransID,@ProdID,@ProdName,@Quantity,@Price,@TotalPrice,@disc_code,@disc_value)"

                    .Parameters.AddWithValue("@TransID", transID)
                    .Parameters.AddWithValue("@ProdID", ProductInList.Cells("ProdID").Value)
                    .Parameters.AddWithValue("@ProdName", ProductInList.Cells("Item").Value)
                    .Parameters.AddWithValue("@Quantity", ProductInList.Cells("Qty").Value)
                    .Parameters.AddWithValue("@Price", FormatNumber(ProductInList.Cells("OriginalPrice").Value, 2))
                    .Parameters.AddWithValue("@TotalPrice", FormatNumber(ProductInList.Cells("Price").Value, 2))
                    .Parameters.AddWithValue("@disc_code", ProductInList.Cells("Disc_Code").Value)
                    .Parameters.AddWithValue("@disc_value", FormatNumber(ProductInList.Cells("Discount").Value, 2))
                    '.Parameters.AddWithValue("@crid", ReadingID)

                    'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                    result = COMMAND.ExecuteNonQuery
                    'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                    If result = 0 Then
                        MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                        Exit Sub
                    End If
                End With

                'ADD SINGLE ITEMS TO ForPurchase
                If ProductInList.Cells("Item_type").Value = "SINGLE" Then
                    pos_ItemsForPuchase.Rows.Add(ProductInList.Cells("ProdID").Value, ProductInList.Cells("ProdID").Value, ProductInList.Cells("Item").Value, ProductInList.Cells("Qty").Value)
                End If


                COMMAND.Parameters.Clear()
            Next
            'MsgBox("Processed Successfully!", vbInformation + vbOKOnly, "Process Complete")
            COMMAND.Parameters.Clear()

            'record Purchased Items
            displayForPurchase()
            generatePuchasedItem(transID)

            'PRINT RECEIPT FORM
            Dim preview As New ReceiptPreview
            preview.strPrint = PrepareTransactionReceipt(transID, 1, "", SoldTo)
            'preview.strPrint = PrepareTransactionReceipt(GetLastTransID(CashierID, ReadingID), 1, "", SoldTo)
            preview.ShowDialog()

            'HasAppliedDisc = False

            'CLEAR FlowLayoutPanel Controls
            If FlowLayoutPanel1.Controls.Count > 0 Then
                Dim cnt As Integer = FlowLayoutPanel1.Controls.Count - 1
                While FlowLayoutPanel1.Controls.Count > 0
                    FlowLayoutPanel1.Controls(cnt).Dispose()
                    cnt -= 1
                End While
            End If

            DataGridView1.Rows.Clear()
            resetFields()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try

        COMMAND.Parameters.Clear()
    End Sub

    Public Function PrepareTransactionReceipt(transID As Integer, printmode As Integer, printDate As String, soldto As String)
        Dim strPrint As String

        'Dim config As New IniFile(Application.StartupPath & "\" & "Config.ini")

        'RECEIPT HEADER
        Dim CompanyName As String = "Don Buchi"
        Dim CompanyAddress As String = "National Rd, Muntinlupa"
        'Dim CompanyName As String = config.GetString("Receipt", "StoreName", "Company XYZ")
        'Dim CompanyAddress As String = config.GetString("Receipt", "StoreAddress", "Address Here")

        strPrint = " " & vbCrLf
        'strPrint = strPrint & " " & vbCrLf
        strPrint = strPrint & CompanyName.ToString.PadLeft(21) & vbCrLf
        strPrint = strPrint & CompanyAddress.ToString.PadLeft(28) & vbCrLf
        If printmode = 2 Then 'RE-PRINT
            strPrint = strPrint & "RE-PRINTED RECEIPT".ToString.PadLeft(26) & vbCrLf
        Else
            'do nothing
        End If
        strPrint = strPrint & " " & vbNewLine

        'BODY
        Dim sql As String
        Dim table As New DataTable

        'Transaction Number and Date
        If printmode = 2 Then 'RE-PRINT
            strPrint = strPrint & "".PadRight(3) & "TN:".ToString.PadRight(2) & transID.ToString.PadRight(10) & "Date:".PadRight(2) & printDate & vbCrLf
        Else
            strPrint = strPrint & "".PadRight(3) & "TN:".ToString.PadRight(2) & transID.ToString.PadRight(10) & "Date:".PadRight(2) & Format(Date.Today, "MM/dd/yyyy") & vbCrLf
        End If

        strPrint = strPrint & "" & vbNewLine & vbCrLf
        strPrint = strPrint & " ---------------------------------" & vbCrLf
        strPrint = strPrint & " " & vbNewLine

        'Items
        sql = "SELECT item, quantity, price, discValue," _
            & "(SELECT AmountPaid FROM transactionhistory where transactionNo = transactiondetails.transactionNo) as AmountPaid," _
            & "(SELECT ChangeAmount FROM transactionhistory where transactionNo = transactiondetails.transactionNo) as ChangeAmt " _
            & "FROM transactiondetails WHERE transactionNo = @transID"
        table = New DataTable
        Try
            openConnection()

            With COMMAND
                .CommandText = sql
                .Connection = MysqlConn
                .Parameters.AddWithValue("@transID", transID)
            End With

            da.SelectCommand = COMMAND
            da.Fill(table)

            COMMAND.Parameters.Clear()

            Dim totalqty As Integer = 0
            Dim subtotal As Double = 0.0
            Dim totaldisc As Double = 0.0
            Dim amtPaid As Double = 0.0
            Dim change As Double = 0.0

            For Each row As DataRow In table.Rows
                Dim quantity As Integer = row.Item("quantity")
                Dim price As Double = FormatNumber(row.Item("price"), 2)
                Dim totalprice As Double = FormatNumber(quantity * price)
                Dim disc As Double = FormatNumber(row.Item("discValue"), 2)
                totalqty += quantity
                subtotal += totalprice
                totaldisc += disc
                amtPaid = FormatNumber(row.Item("AmountPaid"), 2)
                change = FormatNumber(row.Item("ChangeAmt"), 2)
                strPrint = strPrint & "".PadRight(1) & Strings.Left(row.Item("item"), 17).ToString.PadRight(20) & (price & "x" & quantity).ToString.PadRight(7) & FormatNumber(totalprice, 2).ToString.PadLeft(6) & vbCrLf
            Next


            'Subtotal,Vatable,VAT
            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Sub Total".ToString.PadRight(20) & FormatNumber(subtotal, 2).ToString.PadLeft(13) & vbCrLf

            subtotal = subtotal - totaldisc 'Discount deducted to subtotal

            strPrint = strPrint & " " & vbCrLf
            strPrint = strPrint & " ".PadRight(1) & "LESS:" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "DISCOUNT".ToString.PadRight(20) & FormatNumber(totaldisc, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "No of Items".ToString.PadRight(20) & totalqty.ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Vatable".ToString.PadRight(20) & FormatNumber(subtotal / Vatable, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "VAT".ToString.PadRight(20) & FormatNumber(FormatNumber(subtotal / Vatable, 2) * VAT, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "TOTAL".ToString.PadRight(20) & FormatNumber(subtotal, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & " ---------------------------------" & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "SOLD TO".ToString.PadRight(20) & soldto.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Amount Paid".ToString.PadRight(20) & FormatNumber(amtPaid, 2).ToString.PadLeft(13) & vbCrLf
            strPrint = strPrint & "".PadRight(1) & "Change".ToString.PadRight(20) & FormatNumber(change, 2).ToString.PadLeft(13) & vbCrLf
        Catch ex As Exception
            'MsgBox(ex.Message)
            If MsgBox(ex.Message) = DialogResult.OK Then
                COMMAND.Parameters.Clear()
            End If
        End Try

        'FOOTER
        Dim Message1 As String = "This serves as your"
        Dim Message2 As String = "Official Receipt"
        Dim Message3 As String = "Thank You!"
        'Dim Message1 As String = config.GetString("Receipt", "Message1", "Message1")
        'Dim Message2 As String = config.GetString("Receipt", "Message2", "Message2")
        'Dim Message3 As String = config.GetString("Receipt", "Message3", "Message3")

        strPrint = strPrint & " " & vbCrLf
        strPrint = strPrint & Message1.ToString.PadLeft(26.5) & vbCrLf
        strPrint = strPrint & Message2.ToString.PadLeft(25) & vbCrLf
        strPrint = strPrint & Message3.ToString.PadLeft(22) & vbCrLf

        Return strPrint
        'Printer.Print(strPrint)
    End Function

    Sub generatePuchasedItem(transactionNo As Integer)
        'displayForPurchase()
        Dim result As Integer

        Try
            'we open Connection
            openConnection()
            'Dim cat_index As Integer = ComboBox1.SelectedIndex
            Dim ctr As Integer
            Dim row_count As Integer = pos_ItemsForPuchase.Rows.Count - 1
            For Each ForPurchase As DataGridViewRow In pos_ItemsForPuchase.Rows
                If ctr < row_count Then
                    With COMMAND
                        .Connection = MysqlConn
                        .CommandText = "INSERT INTO purchaseditems" _
                            & "(transactionNo,prod_id,prod_name,quantity) " _
                            & "VALUES(@TransID,@ProdID,@ProdName,@Quantity)"

                        .Parameters.AddWithValue("@TransID", transactionNo)
                        .Parameters.AddWithValue("@ProdID", ForPurchase.Cells("Prod_id").Value)
                        .Parameters.AddWithValue("@ProdName", ForPurchase.Cells("Prod_name").Value)
                        .Parameters.AddWithValue("@Quantity", ForPurchase.Cells("Qty").Value)


                        'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                        result = COMMAND.ExecuteNonQuery
                        'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                        If result = 0 Then
                            MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                            Exit Sub
                        End If
                    End With
                    COMMAND.Parameters.Clear()
                End If
                ctr += 1
            Next
            'MsgBox("Processed Successfully!", vbInformation + vbOKOnly, "Process Complete")

            CreateForPurchaseRows()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub

    Sub DeleteForPurchase(itemIndex As Integer)

        For j = pos_ItemsForPuchase.RowCount - 1 To 0 Step -1
            If pos_ItemsForPuchase(0, j).Value = itemIndex Then
                pos_ItemsForPuchase.Rows.RemoveAt(j)
            End If
            displayForPurchase()
        Next

    End Sub

    Sub displayForPurchase()

        For index As Integer = 0 To pos_ItemsForPuchase.RowCount - 2
            Console.WriteLine(pos_ItemsForPuchase.Rows(index).Cells(0).Value & "/" & pos_ItemsForPuchase.Rows(index).Cells(1).Value & "/" & pos_ItemsForPuchase.Rows(index).Cells(2).Value & "/" & pos_ItemsForPuchase.Rows(index).Cells(3).Value)
        Next
        'For Each oRow As DataGridViewRow In pos_ItemsForPuchase.Rows
        '    Dim str As String = oRow.Cells(0).Value & "/" & oRow.Cells(1).Value & "/" & oRow.Cells(2).Value & "/" & oRow.Cells(3).Value
        '    Console.WriteLine(str)
        'Next
        Console.WriteLine("ITEM COUNT: " & pos_ItemsForPuchase.Rows.Count - 1)
    End Sub

    Private Sub btnTransactions_Click(sender As Object, e As EventArgs) Handles btnTransactions.Click
        Dim Form_transaction As New POS_Transactions
        With Form_transaction
            .ShowDialog()
        End With
    End Sub
End Class