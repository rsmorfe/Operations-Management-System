﻿
Imports System.Windows.Forms

Public Class Index
    'VARIABLES
    Public InventoryForm As New Inventory
    Dim UserLevel As Integer


    Private Sub Index_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        loadUser(logged_user_id)
    End Sub
    
    Sub loadUser(user_id As Integer)
        Dim sql As String
        Dim dtable As New DataTable

        sql = "select LastName,User_Level from users WHERE User_id = @user_id"

        Try
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@user_id", user_id)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dtable)

            'lblLastname.Text = dtable.Rows(0).Item(0)
            LoggedUser.Text = "User: " & getUserName(logged_user_id)
            DBase.Text = "database: " & db_database
            UserLevel = dtable.Rows(0).Item(1)

            If Not UserLevel = 1 Then
                btnCreateAccount.Visible = False
            End If

            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try

    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        If MsgBox("Do you want to close the program?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
            closeConnection()
            Application.Exit()
        End If
    End Sub

    Private Sub Category_Click(sender As Object, e As EventArgs) Handles Category.Click
        If Application.OpenForms().OfType(Of Category).Any Then
            'Do Nothing
        Else
            Dim CategoryForm As New Category
            CategoryForm.MdiParent = Me
            CategoryForm.Show()
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblDate1.Text = Date.Now.ToString("dd-MM-yyyy")
        lblTime1.Text = Date.Now.ToString("hh:mm:ss")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Application.OpenForms().OfType(Of Products).Any Then
            'Do Nothing
        Else
            Dim ProductsForm As New Products
            ProductsForm.MdiParent = Me
            ProductsForm.Show()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Application.OpenForms().OfType(Of Inventory).Any Then
            'Do Nothing
        Else
            InventoryForm = New Inventory 'RE-INITIALIZE
            With InventoryForm
                .MdiParent = Me
                .Show()
            End With
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Application.OpenForms().OfType(Of Supplier).Any Then
            'Do Nothing
        Else
            Dim SupplierForm As New Supplier
            SupplierForm.MdiParent = Me
            SupplierForm.Show()
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If Application.OpenForms().OfType(Of Account).Any Then
            'Do Nothing
        Else
            Dim AccountForm As New Account
            AccountForm.MdiParent = Me
            AccountForm.Show()
        End If
    End Sub

    Private Sub btnCreateAccount_Click(sender As Object, e As EventArgs) Handles btnCreateAccount.Click
        If Application.OpenForms().OfType(Of Create_Account).Any Then
            'Do Nothing
        Else
            Dim CreateAccountForm As New Create_Account
            CreateAccountForm.MdiParent = Me
            CreateAccountForm.Show()
        End If
    End Sub

    Private Sub btnDashboard_Click(sender As Object, e As EventArgs) Handles btnDashboard.Click
        If Application.OpenForms().OfType(Of Dashboard).Any Then
            'Do Nothing
        Else
            Dim DashboardForm As New Dashboard
            DashboardForm.MdiParent = Me
            DashboardForm.Show()
        End If
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        If Application.OpenForms().OfType(Of Reports).Any Then
            'Do Nothing
        Else
            Dim ReportsForm As New Reports
            ReportsForm.MdiParent = Me
            ReportsForm.Show()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        With Discount
            .loadDiscounts()
            .MdiParent = Me
            .Show()
        End With
    End Sub

End Class