﻿Imports System.Windows.Forms
Imports CrystalDecisions.ReportSource
Imports CrystalDecisions.CrystalReports.Engine

Public Class Reports

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnProdList_Click(sender As Object, e As EventArgs) Handles btnProdList.Click
        Dim objRpt As New ProductsList
        objRpt.Refresh()

        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Product List"
        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub

    Private Sub btnInventoryList_Click(sender As Object, e As EventArgs) Handles btnInventoryList.Click
        Dim objRpt As New InventoryList
        objRpt.Refresh()

        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Inventory List"
        Dim rptview As New ReportViewer
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub

    Private Sub btnStockLevel_Click(sender As Object, e As EventArgs) Handles btnStockLevel.Click
        Dim objRpt As New CriticalStockLevel 'new instance of the Crystal Reports FILE
        objRpt.Refresh()

        'THIS IS FOR RENAMING THE REPORT TITLE IN CASE YOU NEED TO DYNAMICALLY CHANGE IT BEFORE LOADING IT
        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Critical Stock Level"
        Dim rptview As New ReportViewer 'new instance of the ReportViewer form
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt 'refer the CR object to the datasource of the viewer
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index 'this makes the report a part of the parent form that is declared an MDI PARENT
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized 'maximize the form
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub

    Private Sub btnTotalSales_Click(sender As Object, e As EventArgs) Handles btnTotalSales.Click
        Dim objRpt As New TotalSales 'new instance of the Crystal Reports FILE
        objRpt.Refresh()

        'THIS IS FOR RENAMING THE REPORT TITLE IN CASE YOU NEED TO DYNAMICALLY CHANGE IT BEFORE LOADING IT
        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Daily Sales"
        Dim rptview As New ReportViewer 'new instance of the ReportViewer form
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt 'refer the CR object to the datasource of the viewer
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index 'this makes the report a part of the parent form that is declared an MDI PARENT
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized 'maximize the form
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub

    Private Sub btnTotalMonthSales_Click(sender As Object, e As EventArgs) Handles btnTotalMonthSales.Click
        Dim objRpt As New TotalSales_ThisMonth 'new instance of the Crystal Reports FILE
        objRpt.Refresh()

        'THIS IS FOR RENAMING THE REPORT TITLE IN CASE YOU NEED TO DYNAMICALLY CHANGE IT BEFORE LOADING IT
        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Monthly Sales"
        Dim rptview As New ReportViewer 'new instance of the ReportViewer form
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt 'refer the CR object to the datasource of the viewer
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index 'this makes the report a part of the parent form that is declared an MDI PARENT
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized 'maximize the form
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub

    Private Sub btnGrossSales_Click(sender As Object, e As EventArgs) Handles btnGrossSales.Click
        Dim objRpt As New GrossSales_ThisYear 'new instance of the Crystal Reports FILE
        objRpt.Refresh()

        'THIS IS FOR RENAMING THE REPORT TITLE IN CASE YOU NEED TO DYNAMICALLY CHANGE IT BEFORE LOADING IT
        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Gross Sales"
        Dim rptview As New ReportViewer 'new instance of the ReportViewer form
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt 'refer the CR object to the datasource of the viewer
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index 'this makes the report a part of the parent form that is declared an MDI PARENT
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized 'maximize the form
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub


    Private Sub btnSoldProducts_Click(sender As Object, e As EventArgs) Handles btnSoldProducts.Click
        Dim objRpt As New SoldProducts 'new instance of the Crystal Reports FILE
        objRpt.Refresh()

        'THIS IS FOR RENAMING THE REPORT TITLE IN CASE YOU NEED TO DYNAMICALLY CHANGE IT BEFORE LOADING IT
        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Sold Products Summary"
        Dim rptview As New ReportViewer 'new instance of the ReportViewer form
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt 'refer the CR object to the datasource of the viewer
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index 'this makes the report a part of the parent form that is declared an MDI PARENT
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized 'maximize the form
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub

    Private Sub btnSoldBundle_Click(sender As Object, e As EventArgs) Handles btnSoldBundle.Click
        Dim objRpt As New SoldBundledProducts 'new instance of the Crystal Reports FILE
        objRpt.Refresh()

        'THIS IS FOR RENAMING THE REPORT TITLE IN CASE YOU NEED TO DYNAMICALLY CHANGE IT BEFORE LOADING IT
        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Sold Bundled Products"
        Dim rptview As New ReportViewer 'new instance of the ReportViewer form
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt 'refer the CR object to the datasource of the viewer
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index 'this makes the report a part of the parent form that is declared an MDI PARENT
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized 'maximize the form
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub

    Private Sub btnVoided_Click(sender As Object, e As EventArgs) Handles btnVoided.Click
        Dim objRpt As New VoidedTransactions 'new instance of the Crystal Reports FILE
        objRpt.Refresh()

        'THIS IS FOR RENAMING THE REPORT TITLE IN CASE YOU NEED TO DYNAMICALLY CHANGE IT BEFORE LOADING IT
        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Voided Transactions"
        Dim rptview As New ReportViewer 'new instance of the ReportViewer form
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt 'refer the CR object to the datasource of the viewer
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index 'this makes the report a part of the parent form that is declared an MDI PARENT
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized 'maximize the form
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub

    Private Sub btnConsumedItems_Click(sender As Object, e As EventArgs) Handles btnConsumedItems.Click
        Dim objRpt As New ConsumedItems 'new instance of the Crystal Reports FILE
        objRpt.Refresh()

        'THIS IS FOR RENAMING THE REPORT TITLE IN CASE YOU NEED TO DYNAMICALLY CHANGE IT BEFORE LOADING IT
        DirectCast(objRpt.ReportDefinition.ReportObjects("txtReportTitle"), TextObject).Text = "Consumed Items"
        Dim rptview As New ReportViewer 'new instance of the ReportViewer form
        With rptview
            .CrystalReportViewer1.ReportSource = objRpt 'refer the CR object to the datasource of the viewer
            .CrystalReportViewer1.Parent = rptview
            .CrystalReportViewer1.Refresh()
            .CrystalReportViewer1.RefreshReport()
            .MdiParent = Index 'this makes the report a part of the parent form that is declared an MDI PARENT
            .Dock = DockStyle.Fill
            .WindowState = FormWindowState.Maximized 'maximize the form
            .FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle
            .Show()
        End With

        Me.Close()
    End Sub
End Class