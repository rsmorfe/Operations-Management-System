﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Reports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnProdList = New System.Windows.Forms.Button()
        Me.btnInventoryList = New System.Windows.Forms.Button()
        Me.btnStockLevel = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnTotalSales = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnVoided = New System.Windows.Forms.Button()
        Me.btnSoldBundle = New System.Windows.Forms.Button()
        Me.btnSoldProducts = New System.Windows.Forms.Button()
        Me.btnTotalMonthSales = New System.Windows.Forms.Button()
        Me.btnGrossSales = New System.Windows.Forms.Button()
        Me.btnConsumedItems = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnProdList
        '
        Me.btnProdList.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnProdList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProdList.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProdList.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnProdList.Location = New System.Drawing.Point(20, 65)
        Me.btnProdList.Name = "btnProdList"
        Me.btnProdList.Size = New System.Drawing.Size(171, 62)
        Me.btnProdList.TabIndex = 2
        Me.btnProdList.Text = "Product List"
        Me.btnProdList.UseVisualStyleBackColor = False
        '
        'btnInventoryList
        '
        Me.btnInventoryList.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnInventoryList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnInventoryList.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInventoryList.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnInventoryList.Location = New System.Drawing.Point(20, 132)
        Me.btnInventoryList.Name = "btnInventoryList"
        Me.btnInventoryList.Size = New System.Drawing.Size(171, 62)
        Me.btnInventoryList.TabIndex = 3
        Me.btnInventoryList.Text = "Inventory List"
        Me.btnInventoryList.UseVisualStyleBackColor = False
        '
        'btnStockLevel
        '
        Me.btnStockLevel.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnStockLevel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStockLevel.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStockLevel.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnStockLevel.Location = New System.Drawing.Point(20, 200)
        Me.btnStockLevel.Name = "btnStockLevel"
        Me.btnStockLevel.Size = New System.Drawing.Size(171, 62)
        Me.btnStockLevel.TabIndex = 4
        Me.btnStockLevel.Text = "Critical Stock Level"
        Me.btnStockLevel.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Trebuchet MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(56, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 22)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "INVENTORY"
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClose.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnClose.Location = New System.Drawing.Point(398, 332)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(171, 62)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnTotalSales
        '
        Me.btnTotalSales.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnTotalSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTotalSales.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTotalSales.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnTotalSales.Location = New System.Drawing.Point(209, 65)
        Me.btnTotalSales.Name = "btnTotalSales"
        Me.btnTotalSales.Size = New System.Drawing.Size(171, 62)
        Me.btnTotalSales.TabIndex = 7
        Me.btnTotalSales.Text = "Total Sales (Daily)"
        Me.btnTotalSales.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Trebuchet MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(267, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 22)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "SALES"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Trebuchet MS", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(464, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 22)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "POS"
        '
        'btnVoided
        '
        Me.btnVoided.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnVoided.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVoided.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVoided.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnVoided.Location = New System.Drawing.Point(398, 201)
        Me.btnVoided.Name = "btnVoided"
        Me.btnVoided.Size = New System.Drawing.Size(171, 62)
        Me.btnVoided.TabIndex = 12
        Me.btnVoided.Text = "Voided Transactions"
        Me.btnVoided.UseVisualStyleBackColor = False
        '
        'btnSoldBundle
        '
        Me.btnSoldBundle.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnSoldBundle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSoldBundle.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSoldBundle.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSoldBundle.Location = New System.Drawing.Point(398, 133)
        Me.btnSoldBundle.Name = "btnSoldBundle"
        Me.btnSoldBundle.Size = New System.Drawing.Size(171, 62)
        Me.btnSoldBundle.TabIndex = 11
        Me.btnSoldBundle.Text = "Sold Products (Bundle)"
        Me.btnSoldBundle.UseVisualStyleBackColor = False
        '
        'btnSoldProducts
        '
        Me.btnSoldProducts.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnSoldProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSoldProducts.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSoldProducts.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSoldProducts.Location = New System.Drawing.Point(398, 65)
        Me.btnSoldProducts.Name = "btnSoldProducts"
        Me.btnSoldProducts.Size = New System.Drawing.Size(171, 62)
        Me.btnSoldProducts.TabIndex = 10
        Me.btnSoldProducts.Text = "Sold Products"
        Me.btnSoldProducts.UseVisualStyleBackColor = False
        '
        'btnTotalMonthSales
        '
        Me.btnTotalMonthSales.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnTotalMonthSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTotalMonthSales.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTotalMonthSales.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnTotalMonthSales.Location = New System.Drawing.Point(209, 132)
        Me.btnTotalMonthSales.Name = "btnTotalMonthSales"
        Me.btnTotalMonthSales.Size = New System.Drawing.Size(171, 62)
        Me.btnTotalMonthSales.TabIndex = 13
        Me.btnTotalMonthSales.Text = "Total Sales (Month)"
        Me.btnTotalMonthSales.UseVisualStyleBackColor = False
        '
        'btnGrossSales
        '
        Me.btnGrossSales.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnGrossSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGrossSales.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGrossSales.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnGrossSales.Location = New System.Drawing.Point(209, 200)
        Me.btnGrossSales.Name = "btnGrossSales"
        Me.btnGrossSales.Size = New System.Drawing.Size(171, 62)
        Me.btnGrossSales.TabIndex = 14
        Me.btnGrossSales.Text = "Gross Total Sales"
        Me.btnGrossSales.UseVisualStyleBackColor = False
        '
        'btnConsumedItems
        '
        Me.btnConsumedItems.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnConsumedItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnConsumedItems.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConsumedItems.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnConsumedItems.Location = New System.Drawing.Point(20, 268)
        Me.btnConsumedItems.Name = "btnConsumedItems"
        Me.btnConsumedItems.Size = New System.Drawing.Size(171, 62)
        Me.btnConsumedItems.TabIndex = 15
        Me.btnConsumedItems.Text = "Consumed Items"
        Me.btnConsumedItems.UseVisualStyleBackColor = False
        '
        'Reports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Linen
        Me.ClientSize = New System.Drawing.Size(588, 406)
        Me.Controls.Add(Me.btnConsumedItems)
        Me.Controls.Add(Me.btnGrossSales)
        Me.Controls.Add(Me.btnTotalMonthSales)
        Me.Controls.Add(Me.btnVoided)
        Me.Controls.Add(Me.btnSoldBundle)
        Me.Controls.Add(Me.btnSoldProducts)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnTotalSales)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnStockLevel)
        Me.Controls.Add(Me.btnInventoryList)
        Me.Controls.Add(Me.btnProdList)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Reports"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Report Selector"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnProdList As System.Windows.Forms.Button
    Friend WithEvents btnInventoryList As System.Windows.Forms.Button
    Friend WithEvents btnStockLevel As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnTotalSales As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnVoided As System.Windows.Forms.Button
    Friend WithEvents btnSoldBundle As System.Windows.Forms.Button
    Friend WithEvents btnSoldProducts As System.Windows.Forms.Button
    Friend WithEvents btnTotalMonthSales As System.Windows.Forms.Button
    Friend WithEvents btnGrossSales As System.Windows.Forms.Button
    Friend WithEvents btnConsumedItems As System.Windows.Forms.Button
End Class
