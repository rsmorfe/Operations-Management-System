﻿Imports MySql.Data.MySqlClient
Public Class Category
   
    Private Sub Category_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Catlist()
        dgvCategory.ClearSelection()
    End Sub
  
    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        If checkIfExists(catname.Text) = True Then
            MsgBox("Category name already exists", vbExclamation + vbOKOnly, "Already Exists")
            catname.Text = ""
            catname.Focus()
        Else
            Dim result As Integer

            If catname.Text = "" Then
                MessageBox.Show("Incomplete Data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                Try
                    openConnection()

                    Dim query As String
                    query = "insert into category (cat_name) values(@catname)"

                    With COMMAND
                        .Connection = MysqlConn
                        .CommandText = query
                        .Parameters.AddWithValue("@catname", catname.Text)

                        'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                        result = COMMAND.ExecuteNonQuery
                        'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                        If result = 0 Then
                            MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                        Else
                            MessageBox.Show("Category Added Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                        End If
                    End With

                    closeConnection()
                    clearFields()
                    Catlist()
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
                COMMAND.Parameters.Clear()
            End If
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If cat_id.Text = "" Or catname.Text = "" Then
            MessageBox.Show("Incomplete Data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            openConnection()

            Dim sql = "UPDATE category set cat_name='" & catname.Text & "' where cat_id=" & cat_id.Text & ""
            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .ExecuteNonQuery()
            End With

            MessageBox.Show("Update Successfully", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            closeConnection()
            clearFields()
            Catlist()
        End If

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If dgvCategory.Rows.Count = 0 Then
            'Do Nothing
        Else
            If MsgBox("Do you really want to delete this item?", vbQuestion + vbYesNo, "Confirmation") = MsgBoxResult.Yes Then
                openConnection()
                Dim sql As String
                sql = "delete from category where cat_id = @catid"

                Try
                    With COMMAND
                        .CommandText = sql
                        .Connection = MysqlConn
                        .Parameters.AddWithValue("@catid", dgvCategory.CurrentRow.Cells(0).Value)
                        .ExecuteNonQuery()
                    End With

                    MessageBox.Show("Category Deleted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    closeConnection()
                    COMMAND.Parameters.Clear()
                    Catlist()
                Catch ex As Exception
                    MsgBox(ex.Message)
                    COMMAND.Parameters.Clear()
                End Try

            End If
        End If
    End Sub

    Private Sub dgvCategory_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvCategory.CellDoubleClick
        Dim row As DataGridViewRow = dgvCategory.CurrentRow
        cat_id.Text = row.Cells(0).Value.ToString()
        catname.Text = row.Cells(1).Value.ToString()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Public Sub Catlist()
        Try
            openConnection()

            Dim ds As DataSet
            ds = New DataSet
            Dim sql = "select cat_id, cat_name from category"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(ds)

            closeConnection()
            dgvCategory.DataSource = ds.Tables(0)

            dgvCategory.Columns.Item(0).HeaderText = "ID"
            dgvCategory.Columns.Item(1).HeaderText = "Category Name"
            dgvCategory.Columns.Item(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Function checkIfExists(category As String)
        Dim result As Boolean

        Try
            openConnection()

            Dim dt As New DataTable
            Dim sql = "select cat_id, cat_name from category where cat_name = @catname"

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@catname", category)
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            closeConnection()

            If dt.Rows.Count > 0 Then
                result = True
            End If

            dt.Dispose()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        COMMAND.Parameters.Clear()

        Return result
    End Function

    Sub clearFields()
        cat_id.Text = ""
        catname.Text = ""
    End Sub
End Class