﻿Public Class POS_CheckoutSummary
    Public TotalItems As Integer
    Public TotalAmount As Double
    Public TotalVatable As Double
    Public TotalVat As Double
    Public totalDiscount As Double

    Sub LoadSubtotal()
        TextBox1.Text = FormatNumber(TotalAmount, 2)
    End Sub

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        If Len(Trim(TextBox2.Text)) = 0 Then
            MsgBox("Enter an amount", vbExclamation + vbOKOnly, "System")
        ElseIf CDbl(TextBox3.Text) <> 0.0 Then
            MsgBox("Amount entered doesn't match with the Total Due", vbExclamation + vbOKOnly, "System")
            TextBox2.Focus()
        Else
            Me.Close()
            POS.CreateTransactionHeader(TotalItems, TotalAmount, TotalVatable, TotalVat, totalDiscount, txtSoldTo.Text, CDbl(TextBox2.Text), CDbl(TextBox4.Text), logged_user_id)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        Dim DecimalSeparator As String = Application.CurrentCulture.NumberFormat.NumberDecimalSeparator
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                         Asc(e.KeyChar) = 8 Or
                         (e.KeyChar = DecimalSeparator And sender.Text.IndexOf(DecimalSeparator) = -1))

        If Char.IsControl(e.KeyChar) Then
        ElseIf Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "."c Then
            'If TextBox2.TextLength = 5 And TextBox2.Text.Contains(".") = False Then
            'TextBox2.AppendText(".")
            'Elseif
            If e.KeyChar = "." And TextBox2.Text.IndexOf(".") <> -1 Then
                e.Handled = True
            ElseIf Char.IsDigit(e.KeyChar) Then
                If TextBox2.Text.IndexOf(".") <> -1 Then
                    If TextBox2.Text.Length >= TextBox2.Text.IndexOf(".") + 3 Then
                        e.Handled = True
                    End If
                End If
            End If
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Dim balance As Double
        Dim change As Double
        If TextBox2.Text.Equals("") Then
            'Do Nothing
        Else
            balance = FormatNumber(CDbl(TextBox1.Text) - CDbl(TextBox2.Text), 2)
            If balance < 0 Then
                TextBox3.Text = FormatNumber(0, 2)
            Else
                TextBox3.Text = FormatNumber(balance, 2)
            End If

            change = FormatNumber(CDbl(TextBox2.Text) - CDbl(TextBox1.Text), 2)

            If change < 0 Then
                TextBox4.Text = FormatNumber(0, 2)
            Else
                TextBox4.Text = FormatNumber(change, 2)
            End If
        End If
    End Sub

    
End Class