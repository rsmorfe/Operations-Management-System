﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Inventory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnLoadCritical = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.dgvInv = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.btnInsert = New System.Windows.Forms.Button()
        Me.btnCheckOut = New System.Windows.Forms.Button()
        Me.VerticalMenu = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblProd = New System.Windows.Forms.Label()
        Me.btnLoadConsumed = New System.Windows.Forms.Button()
        Me.pnlHeader.SuspendLayout()
        CType(Me.dgvInv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.VerticalMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlHeader
        '
        Me.pnlHeader.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.pnlHeader.Controls.Add(Me.btnExit)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(819, 50)
        Me.pnlHeader.TabIndex = 5
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnExit.FlatAppearance.BorderSize = 0
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Linen
        Me.btnExit.Location = New System.Drawing.Point(773, 3)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(31, 42)
        Me.btnExit.TabIndex = 18
        Me.btnExit.TabStop = False
        Me.btnExit.Text = "X"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Linen
        Me.Label1.Location = New System.Drawing.Point(394, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 25)
        Me.Label1.TabIndex = 62
        Me.Label1.Text = "INVENTORY"
        '
        'btnRefresh
        '
        Me.btnRefresh.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRefresh.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnRefresh.Location = New System.Drawing.Point(30, 271)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(170, 72)
        Me.btnRefresh.TabIndex = 69
        Me.btnRefresh.Text = "REFRESH LIST"
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'btnLoadCritical
        '
        Me.btnLoadCritical.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnLoadCritical.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLoadCritical.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoadCritical.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnLoadCritical.Location = New System.Drawing.Point(30, 426)
        Me.btnLoadCritical.Name = "btnLoadCritical"
        Me.btnLoadCritical.Size = New System.Drawing.Size(170, 72)
        Me.btnLoadCritical.TabIndex = 70
        Me.btnLoadCritical.Text = "CRITICAL STOCKS"
        Me.btnLoadCritical.UseVisualStyleBackColor = False
        '
        'txtSearch
        '
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(238, 60)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(273, 26)
        Me.txtSearch.TabIndex = 9
        '
        'dgvInv
        '
        Me.dgvInv.AllowUserToAddRows = False
        Me.dgvInv.AllowUserToDeleteRows = False
        Me.dgvInv.AllowUserToResizeColumns = False
        Me.dgvInv.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.dgvInv.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvInv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvInv.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.dgvInv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvInv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.MediumSlateBlue
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvInv.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvInv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvInv.DoubleBuffered = True
        Me.dgvInv.EnableHeadersVisualStyles = False
        Me.dgvInv.HeaderBgColor = System.Drawing.Color.MediumSlateBlue
        Me.dgvInv.HeaderForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.dgvInv.Location = New System.Drawing.Point(238, 100)
        Me.dgvInv.MultiSelect = False
        Me.dgvInv.Name = "dgvInv"
        Me.dgvInv.ReadOnly = True
        Me.dgvInv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgvInv.RowHeadersVisible = False
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgvInv.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvInv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvInv.Size = New System.Drawing.Size(566, 488)
        Me.dgvInv.TabIndex = 10
        '
        'Button5
        '
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(0, 540)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(200, 48)
        Me.Button5.TabIndex = 5
        Me.Button5.Text = "Logout"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'btnInsert
        '
        Me.btnInsert.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnInsert.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInsert.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnInsert.Location = New System.Drawing.Point(30, 71)
        Me.btnInsert.Name = "btnInsert"
        Me.btnInsert.Size = New System.Drawing.Size(170, 72)
        Me.btnInsert.TabIndex = 1
        Me.btnInsert.Text = "REPLENISH"
        Me.btnInsert.UseVisualStyleBackColor = False
        '
        'btnCheckOut
        '
        Me.btnCheckOut.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnCheckOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCheckOut.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheckOut.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnCheckOut.Location = New System.Drawing.Point(30, 149)
        Me.btnCheckOut.Name = "btnCheckOut"
        Me.btnCheckOut.Size = New System.Drawing.Size(170, 72)
        Me.btnCheckOut.TabIndex = 2
        Me.btnCheckOut.Text = "CHECKOUT"
        Me.btnCheckOut.UseVisualStyleBackColor = False
        '
        'VerticalMenu
        '
        Me.VerticalMenu.BackColor = System.Drawing.Color.Linen
        Me.VerticalMenu.Controls.Add(Me.btnLoadConsumed)
        Me.VerticalMenu.Controls.Add(Me.Label2)
        Me.VerticalMenu.Controls.Add(Me.lblProd)
        Me.VerticalMenu.Controls.Add(Me.btnRefresh)
        Me.VerticalMenu.Controls.Add(Me.btnLoadCritical)
        Me.VerticalMenu.Controls.Add(Me.btnCheckOut)
        Me.VerticalMenu.Controls.Add(Me.btnInsert)
        Me.VerticalMenu.Controls.Add(Me.Button5)
        Me.VerticalMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.VerticalMenu.Location = New System.Drawing.Point(0, 50)
        Me.VerticalMenu.Name = "VerticalMenu"
        Me.VerticalMenu.Size = New System.Drawing.Size(221, 550)
        Me.VerticalMenu.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(48, 233)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 19)
        Me.Label2.TabIndex = 72
        Me.Label2.Text = "INVENTORY LIST"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblProd
        '
        Me.lblProd.AutoSize = True
        Me.lblProd.BackColor = System.Drawing.Color.Transparent
        Me.lblProd.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProd.ForeColor = System.Drawing.Color.Black
        Me.lblProd.Location = New System.Drawing.Point(78, 31)
        Me.lblProd.Name = "lblProd"
        Me.lblProd.Size = New System.Drawing.Size(76, 19)
        Me.lblProd.TabIndex = 71
        Me.lblProd.Text = "PROCESS"
        Me.lblProd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnLoadConsumed
        '
        Me.btnLoadConsumed.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnLoadConsumed.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLoadConsumed.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoadConsumed.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnLoadConsumed.Location = New System.Drawing.Point(30, 348)
        Me.btnLoadConsumed.Name = "btnLoadConsumed"
        Me.btnLoadConsumed.Size = New System.Drawing.Size(170, 72)
        Me.btnLoadConsumed.TabIndex = 73
        Me.btnLoadConsumed.Text = "CONSUMED ITEMS"
        Me.btnLoadConsumed.UseVisualStyleBackColor = False
        '
        'Inventory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(819, 600)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.dgvInv)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.VerticalMenu)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Inventory"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inventory"
        Me.pnlHeader.ResumeLayout(False)
        CType(Me.dgvInv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.VerticalMenu.ResumeLayout(False)
        Me.VerticalMenu.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnLoadCritical As System.Windows.Forms.Button
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents dgvInv As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents btnInsert As System.Windows.Forms.Button
    Friend WithEvents btnCheckOut As System.Windows.Forms.Button
    Friend WithEvents VerticalMenu As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblProd As System.Windows.Forms.Label
    Friend WithEvents btnLoadConsumed As System.Windows.Forms.Button
End Class
