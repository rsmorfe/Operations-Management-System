﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Products
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.VerticalMenu = New System.Windows.Forms.Panel()
        Me.btnShowBundled = New System.Windows.Forms.Button()
        Me.chkBoxBundle = New System.Windows.Forms.CheckBox()
        Me.chkBoxSingle = New System.Windows.Forms.CheckBox()
        Me.lblType = New System.Windows.Forms.Label()
        Me.txtPOSPrices = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnInsert = New System.Windows.Forms.Button()
        Me.lblSupp = New System.Windows.Forms.Label()
        Me.lblProd = New System.Windows.Forms.Label()
        Me.prodid = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.proddesc = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbVariance = New System.Windows.Forms.ComboBox()
        Me.prodname = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.lblVariance = New System.Windows.Forms.Label()
        Me.cbCategory = New System.Windows.Forms.ComboBox()
        Me.dgvProduct = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.pnlHeader.SuspendLayout()
        Me.VerticalMenu.SuspendLayout()
        CType(Me.dgvProduct, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlHeader
        '
        Me.pnlHeader.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.pnlHeader.Controls.Add(Me.Label1)
        Me.pnlHeader.Controls.Add(Me.btnExit)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(938, 50)
        Me.pnlHeader.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Linen
        Me.Label1.Location = New System.Drawing.Point(431, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 25)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "PRODUCTS"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnExit.FlatAppearance.BorderSize = 0
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Linen
        Me.btnExit.Location = New System.Drawing.Point(896, 3)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(31, 42)
        Me.btnExit.TabIndex = 18
        Me.btnExit.TabStop = False
        Me.btnExit.Text = "X"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'VerticalMenu
        '
        Me.VerticalMenu.BackColor = System.Drawing.Color.Linen
        Me.VerticalMenu.Controls.Add(Me.btnShowBundled)
        Me.VerticalMenu.Controls.Add(Me.chkBoxBundle)
        Me.VerticalMenu.Controls.Add(Me.chkBoxSingle)
        Me.VerticalMenu.Controls.Add(Me.lblType)
        Me.VerticalMenu.Controls.Add(Me.txtPOSPrices)
        Me.VerticalMenu.Controls.Add(Me.btnClear)
        Me.VerticalMenu.Controls.Add(Me.btnDelete)
        Me.VerticalMenu.Controls.Add(Me.Button5)
        Me.VerticalMenu.Controls.Add(Me.btnUpdate)
        Me.VerticalMenu.Controls.Add(Me.btnInsert)
        Me.VerticalMenu.Controls.Add(Me.lblSupp)
        Me.VerticalMenu.Controls.Add(Me.lblProd)
        Me.VerticalMenu.Controls.Add(Me.prodid)
        Me.VerticalMenu.Controls.Add(Me.proddesc)
        Me.VerticalMenu.Controls.Add(Me.Label4)
        Me.VerticalMenu.Controls.Add(Me.Label5)
        Me.VerticalMenu.Controls.Add(Me.cbVariance)
        Me.VerticalMenu.Controls.Add(Me.prodname)
        Me.VerticalMenu.Controls.Add(Me.lblVariance)
        Me.VerticalMenu.Controls.Add(Me.cbCategory)
        Me.VerticalMenu.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.VerticalMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.VerticalMenu.Location = New System.Drawing.Point(0, 343)
        Me.VerticalMenu.Name = "VerticalMenu"
        Me.VerticalMenu.Size = New System.Drawing.Size(938, 257)
        Me.VerticalMenu.TabIndex = 5
        '
        'btnShowBundled
        '
        Me.btnShowBundled.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnShowBundled.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowBundled.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShowBundled.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnShowBundled.Location = New System.Drawing.Point(150, 203)
        Me.btnShowBundled.Name = "btnShowBundled"
        Me.btnShowBundled.Size = New System.Drawing.Size(130, 39)
        Me.btnShowBundled.TabIndex = 66
        Me.btnShowBundled.Text = "Bundled Items"
        Me.btnShowBundled.UseVisualStyleBackColor = False
        Me.btnShowBundled.Visible = False
        '
        'chkBoxBundle
        '
        Me.chkBoxBundle.AutoSize = True
        Me.chkBoxBundle.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBoxBundle.Location = New System.Drawing.Point(691, 134)
        Me.chkBoxBundle.Name = "chkBoxBundle"
        Me.chkBoxBundle.Size = New System.Drawing.Size(93, 25)
        Me.chkBoxBundle.TabIndex = 65
        Me.chkBoxBundle.Text = "Bundled"
        Me.chkBoxBundle.UseVisualStyleBackColor = True
        '
        'chkBoxSingle
        '
        Me.chkBoxSingle.AutoSize = True
        Me.chkBoxSingle.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBoxSingle.Location = New System.Drawing.Point(609, 134)
        Me.chkBoxSingle.Name = "chkBoxSingle"
        Me.chkBoxSingle.Size = New System.Drawing.Size(74, 25)
        Me.chkBoxSingle.TabIndex = 64
        Me.chkBoxSingle.Text = "Single"
        Me.chkBoxSingle.UseVisualStyleBackColor = True
        '
        'lblType
        '
        Me.lblType.AutoSize = True
        Me.lblType.BackColor = System.Drawing.Color.Transparent
        Me.lblType.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.ForeColor = System.Drawing.Color.Black
        Me.lblType.Location = New System.Drawing.Point(511, 135)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(92, 21)
        Me.lblType.TabIndex = 63
        Me.lblType.Text = "Item Type:"
        '
        'txtPOSPrices
        '
        Me.txtPOSPrices.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.txtPOSPrices.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtPOSPrices.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPOSPrices.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtPOSPrices.Location = New System.Drawing.Point(24, 203)
        Me.txtPOSPrices.Name = "txtPOSPrices"
        Me.txtPOSPrices.Size = New System.Drawing.Size(116, 39)
        Me.txtPOSPrices.TabIndex = 62
        Me.txtPOSPrices.Text = "POS Prices"
        Me.txtPOSPrices.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnClear.Location = New System.Drawing.Point(449, 203)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(116, 39)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnDelete.Location = New System.Drawing.Point(811, 203)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(116, 39)
        Me.btnDelete.TabIndex = 11
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(0, 540)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(200, 48)
        Me.Button5.TabIndex = 5
        Me.Button5.Text = "Logout"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnUpdate.Location = New System.Drawing.Point(691, 204)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(116, 39)
        Me.btnUpdate.TabIndex = 10
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnInsert
        '
        Me.btnInsert.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.btnInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnInsert.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInsert.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnInsert.Location = New System.Drawing.Point(571, 203)
        Me.btnInsert.Name = "btnInsert"
        Me.btnInsert.Size = New System.Drawing.Size(116, 39)
        Me.btnInsert.TabIndex = 9
        Me.btnInsert.Text = "Insert"
        Me.btnInsert.UseVisualStyleBackColor = False
        '
        'lblSupp
        '
        Me.lblSupp.AutoSize = True
        Me.lblSupp.BackColor = System.Drawing.Color.Transparent
        Me.lblSupp.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSupp.ForeColor = System.Drawing.Color.Black
        Me.lblSupp.Location = New System.Drawing.Point(20, 28)
        Me.lblSupp.Name = "lblSupp"
        Me.lblSupp.Size = New System.Drawing.Size(31, 21)
        Me.lblSupp.TabIndex = 50
        Me.lblSupp.Text = "ID:"
        '
        'lblProd
        '
        Me.lblProd.AutoSize = True
        Me.lblProd.BackColor = System.Drawing.Color.Transparent
        Me.lblProd.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProd.ForeColor = System.Drawing.Color.Black
        Me.lblProd.Location = New System.Drawing.Point(475, 28)
        Me.lblProd.Name = "lblProd"
        Me.lblProd.Size = New System.Drawing.Size(128, 21)
        Me.lblProd.TabIndex = 61
        Me.lblProd.Text = "Product Name:"
        '
        'prodid
        '
        Me.prodid.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.prodid.Enabled = False
        Me.prodid.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prodid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.prodid.HintForeColor = System.Drawing.Color.Empty
        Me.prodid.HintText = ""
        Me.prodid.isPassword = False
        Me.prodid.LineFocusedColor = System.Drawing.Color.Blue
        Me.prodid.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.prodid.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.prodid.LineThickness = 4
        Me.prodid.Location = New System.Drawing.Point(150, 22)
        Me.prodid.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.prodid.Name = "prodid"
        Me.prodid.Size = New System.Drawing.Size(143, 27)
        Me.prodid.TabIndex = 3
        Me.prodid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'proddesc
        '
        Me.proddesc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.proddesc.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.proddesc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.proddesc.HintForeColor = System.Drawing.Color.Empty
        Me.proddesc.HintText = ""
        Me.proddesc.isPassword = False
        Me.proddesc.LineFocusedColor = System.Drawing.Color.Blue
        Me.proddesc.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.proddesc.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.proddesc.LineThickness = 4
        Me.proddesc.Location = New System.Drawing.Point(24, 161)
        Me.proddesc.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.proddesc.Name = "proddesc"
        Me.proddesc.Size = New System.Drawing.Size(407, 25)
        Me.proddesc.TabIndex = 7
        Me.proddesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(20, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 21)
        Me.Label4.TabIndex = 53
        Me.Label4.Text = "Category :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(20, 135)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(101, 21)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "Description:"
        '
        'cbVariance
        '
        Me.cbVariance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbVariance.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbVariance.FormattingEnabled = True
        Me.cbVariance.Location = New System.Drawing.Point(611, 77)
        Me.cbVariance.Name = "cbVariance"
        Me.cbVariance.Size = New System.Drawing.Size(115, 29)
        Me.cbVariance.TabIndex = 6
        '
        'prodname
        '
        Me.prodname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.prodname.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prodname.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.prodname.HintForeColor = System.Drawing.Color.Empty
        Me.prodname.HintText = ""
        Me.prodname.isPassword = False
        Me.prodname.LineFocusedColor = System.Drawing.Color.Blue
        Me.prodname.LineIdleColor = System.Drawing.Color.MediumSlateBlue
        Me.prodname.LineMouseHoverColor = System.Drawing.Color.Blue
        Me.prodname.LineThickness = 4
        Me.prodname.Location = New System.Drawing.Point(611, 28)
        Me.prodname.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.prodname.Name = "prodname"
        Me.prodname.Size = New System.Drawing.Size(316, 27)
        Me.prodname.TabIndex = 4
        Me.prodname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'lblVariance
        '
        Me.lblVariance.AutoSize = True
        Me.lblVariance.BackColor = System.Drawing.Color.Transparent
        Me.lblVariance.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVariance.ForeColor = System.Drawing.Color.Black
        Me.lblVariance.Location = New System.Drawing.Point(518, 80)
        Me.lblVariance.Name = "lblVariance"
        Me.lblVariance.Size = New System.Drawing.Size(85, 21)
        Me.lblVariance.TabIndex = 56
        Me.lblVariance.Text = "Variance:"
        '
        'cbCategory
        '
        Me.cbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCategory.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbCategory.FormattingEnabled = True
        Me.cbCategory.Location = New System.Drawing.Point(150, 77)
        Me.cbCategory.Name = "cbCategory"
        Me.cbCategory.Size = New System.Drawing.Size(143, 29)
        Me.cbCategory.TabIndex = 5
        '
        'dgvProduct
        '
        Me.dgvProduct.AllowUserToAddRows = False
        Me.dgvProduct.AllowUserToDeleteRows = False
        Me.dgvProduct.AllowUserToResizeColumns = False
        Me.dgvProduct.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.dgvProduct.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvProduct.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.dgvProduct.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvProduct.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.MediumSlateBlue
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvProduct.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvProduct.DoubleBuffered = True
        Me.dgvProduct.EnableHeadersVisualStyles = False
        Me.dgvProduct.HeaderBgColor = System.Drawing.Color.MediumSlateBlue
        Me.dgvProduct.HeaderForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.dgvProduct.Location = New System.Drawing.Point(5, 100)
        Me.dgvProduct.Name = "dgvProduct"
        Me.dgvProduct.ReadOnly = True
        Me.dgvProduct.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvProduct.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvProduct.RowHeadersVisible = False
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgvProduct.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvProduct.Size = New System.Drawing.Size(922, 237)
        Me.dgvProduct.TabIndex = 2
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(16, 60)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(457, 26)
        Me.txtSearch.TabIndex = 1
        '
        'Products
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(938, 600)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.dgvProduct)
        Me.Controls.Add(Me.VerticalMenu)
        Me.Controls.Add(Me.pnlHeader)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Products"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Products"
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.VerticalMenu.ResumeLayout(False)
        Me.VerticalMenu.PerformLayout()
        CType(Me.dgvProduct, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents VerticalMenu As System.Windows.Forms.Panel
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents lblSupp As System.Windows.Forms.Label
    Friend WithEvents prodname As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents cbCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents proddesc As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents lblVariance As System.Windows.Forms.Label
    Friend WithEvents dgvProduct As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents cbVariance As System.Windows.Forms.ComboBox
    Friend WithEvents prodid As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents lblProd As System.Windows.Forms.Label
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnInsert As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents txtPOSPrices As System.Windows.Forms.Button
    Friend WithEvents lblType As System.Windows.Forms.Label
    Friend WithEvents chkBoxBundle As System.Windows.Forms.CheckBox
    Friend WithEvents chkBoxSingle As System.Windows.Forms.CheckBox
    Friend WithEvents btnShowBundled As System.Windows.Forms.Button
End Class
