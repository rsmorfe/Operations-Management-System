﻿Public Class Discount
    'VARIABLES

    'EVENT HANDLERS
    Private Sub Discount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadDiscounts()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnAddDiscount_Click(sender As Object, e As EventArgs) Handles btnAddDiscount.Click
        With Discount_Details
            .Initialize("ADD")
            .txtDiscCode.Enabled = True
            .txtDiscName.Enabled = True
            .ShowDialog()
        End With
    End Sub

    Private Sub dgvDiscounts_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDiscounts.CellDoubleClick
        If dgvDiscounts.Rows.Count > 0 Then
            Dim row As DataGridViewRow = dgvDiscounts.CurrentRow

            With Discount_Details
                .Initialize("EDIT")
                .setDiscountValues(row.Cells(0).Value, row.Cells(1).Value, row.Cells(2).Value)
                .txtDiscCode.Enabled = False
                .txtDiscName.Enabled = False     
                .ShowDialog()
            End With
        End If
    End Sub

    'FUNCTIONS
    Sub loadDiscounts()
        Dim sql As String
        sql = "SELECT disc_code, disc_name, disc_value FROM discounts"
        
        Try
            openConnection()

            Dim dt As New DataTable

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            With dgvDiscounts
                .DataSource = dt
                .Columns.Item(0).HeaderText = "CODE"
                '.Columns.Item(0).Visible = False
                .Columns.Item(1).HeaderText = "Discount"
                .Columns.Item(2).HeaderText = "Value"
                .Columns.Item(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
            End With

            closeConnection()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    
    
End Class