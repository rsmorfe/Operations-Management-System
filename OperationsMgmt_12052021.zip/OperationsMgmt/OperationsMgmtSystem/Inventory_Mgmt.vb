﻿Public Class Inventory_Mgmt
    'VARIABLES
    Public process_type As String
    Dim productstable As New DataTable

    Private Sub Inventory_Mgmt_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If process_type = "REPLENISH" Then
            Index.InventoryForm.btnInsert.BackColor = Color.MediumSlateBlue
        ElseIf process_type = "CHECKOUT" Then
            Index.InventoryForm.btnCheckOut.BackColor = Color.MediumSlateBlue
        End If
    End Sub

    'EVENT HANDLERS
    Private Sub Inventory_Mgmt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtSearch.Clear()
        checkProcess(Me.process_type)
        createSelectedItem_Rows()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub dgvInvItems_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvInvItems.CellDoubleClick
        Dim row As DataGridViewRow = dgvInvItems.CurrentRow
        'inv_id.Text = row.Cells(0).Value.ToString()

        Dim setItemQty As New Inventory_SetQuantity
        With setItemQty
            .setValues(process_type, row.Cells(0).Value, row.Cells(1).Value, row.Cells(2).Value)
            .ShowDialog()
        End With
    End Sub

    Private Sub txtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then
            If txtSearch.Text = "" Then
                MsgBox("Enter the item name", vbInformation + vbOKOnly, "System")
                txtSearch.Focus()
            Else
                searchItem(Me.process_type, txtSearch.Text)
            End If
        End If
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If dgvSelectedItems.Rows.Count = 0 Then
            'Do Nothing
        Else
            dgvSelectedItems.Rows.Remove(dgvSelectedItems.CurrentRow)
        End If
    End Sub

    Private Sub btnProcess_Click(sender As Object, e As EventArgs) Handles btnProcess.Click
        executeProcess(Me.process_type)
    End Sub

    'FUNCTIONS
    Public Sub checkProcess(process As String)
        If process = "REPLENISH" Then
            lblForProcess.Text = "For Replenish:"
            loadProductStocks(process)
        ElseIf process = "CHECKOUT" Then
            lblForProcess.Text = "For Checkout:"
            loadProductStocks(process)
        End If
    End Sub

    Sub createSelectedItem_Rows()
        With dgvSelectedItems
            .DataSource = Nothing
            .Columns.Clear()
            .ClearSelection()
            .Columns.Add("prod_id", "ID")
            .Columns.Add("prod_name", "Product Name")
            .Columns.Add("qty", "Quantity")
            .AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
        End With
    End Sub

    Sub loadProductStocks(process As String)
        Dim sql As String

        If process = "REPLENISH" Then
            Dim ds As New DataSet
            sql = "SELECT " _
              & "a.prod_id AS ID," _
              & "a.prod_name AS ProductName," _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "GROUP BY a.prod_id),0))) AS OnHand " _
              & "FROM products a WHERE a.cat_id NOT IN (5) ORDER BY a.cat_id, a.prod_name"
            '"FROM products a WHERE a.cat_id IN (1,2)"
        ElseIf process = "CHECKOUT" Then
            sql = "SELECT " _
              & "a.prod_id AS ID," _
              & "a.prod_name AS ProductName," _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "GROUP BY a.prod_id),0))) AS OnHand " _
              & "FROM products a WHERE a.cat_id NOT IN (5) AND " _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "GROUP BY a.prod_id),0))) > 0 " _
              & "ORDER BY a.cat_id, a.prod_name"
            '"FROM products a WHERE a.cat_id IN (1,2)"
        End If

        Try
            openConnection()

            Dim dt As New DataTable

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            With dgvInvItems
                .DataSource = dt
                .Columns.Item(0).HeaderText = "ID"
                .Columns.Item(0).Visible = False
                .Columns.Item(1).HeaderText = "Product Name"
                .Columns.Item(2).HeaderText = "On Hand"
            End With

            closeConnection()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Sub searchItem(process As String, item As String)
        Dim sql As String

        If process = "REPLENISH" Then
            sql = "SELECT " _
              & "a.prod_id AS ID," _
              & "a.prod_name AS ProductName," _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "GROUP BY a.prod_id),0))) AS OnHand " _
              & "FROM products a WHERE a.cat_id NOT IN (5) AND a.prod_name LIKE @item " _
              & "ORDER BY a.cat_id, a.prod_name"
            '"FROM products a WHERE a.cat_id IN (1,2)"
        ElseIf process = "CHECKOUT" Then
            sql = "SELECT " _
              & "a.prod_id AS ID," _
              & "a.prod_name AS ProductName," _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "GROUP BY a.prod_id),0))) AS OnHand " _
              & "FROM products a WHERE a.cat_id NOT IN (5) AND a.prod_name LIKE @item AND " _
              & "((COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'REPLENISH' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM stockhistory c WHERE c.prod_id = a.prod_id AND " _
              & "stock_type = 'CHECKOUT' GROUP BY a.prod_id),0)) - " _
              & "(COALESCE((SELECT SUM(quantity) FROM purchaseditems d WHERE d.prod_id = a.prod_id " _
              & "GROUP BY a.prod_id),0))) > 0 " _
              & "ORDER BY a.cat_id, a.prod_name"
            '"FROM products a WHERE a.cat_id IN (1,2)"
        End If

        Try
            openConnection()

            Dim dt As New DataTable

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@item", "%" + item + "%")
            End With

            da.SelectCommand = COMMAND
            da.Fill(dt)

            If dt.Rows.Count > 0 Then
                With dgvInvItems
                    .DataSource = dt
                    .Columns.Item(0).HeaderText = "ID"
                    .Columns.Item(0).Visible = False
                    .Columns.Item(1).HeaderText = "Product Name"
                    .Columns.Item(2).HeaderText = "On Hand"
                End With
            Else
                MsgBox("No record/s found", vbInformation + vbOKOnly, "Result")
                txtSearch.Clear()
                loadProductStocks(Me.process_type)
            End If
            
            COMMAND.Parameters.Clear()
            closeConnection()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub

    Sub executeProcess(process As String)
        Dim result As Integer
        Dim sql As String
        Dim logged_user = getUserName(logged_user_id)

        sql = "insert into stockhistory (prod_id, product_name, stock_type, quantity, createdby)" _
               & "values(@prod_id, @prod_name, @stock_type, @quantity, @createdby)"

        Try
            'we open Connection
            openConnection()

            For Each SelectedItem As DataGridViewRow In dgvSelectedItems.Rows
                '-----------------
                'TESTING CODE ONLY
                'DISPLAY ID OF BOTH Parent Product and Bundled Products, and Quantity
                'value = parent_id & "," & BundledProduct.Cells(0).Value & "," & BundledProduct.Cells(1).Value
                'Console.WriteLine(value)
                '-----------------

                With COMMAND
                    .Connection = MysqlConn
                    .CommandText = sql

                    .Parameters.AddWithValue("@prod_id", SelectedItem.Cells(0).Value)
                    .Parameters.AddWithValue("@prod_name", SelectedItem.Cells(1).Value)
                    .Parameters.AddWithValue("@stock_type", Me.process_type)
                    .Parameters.AddWithValue("@quantity", SelectedItem.Cells(2).Value)
                    .Parameters.AddWithValue("@createdby", logged_user)

                    'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                    result = COMMAND.ExecuteNonQuery
                    'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                    If result = 0 Then
                        MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                        COMMAND.Parameters.Clear()
                        Exit Sub
                    End If
                End With

                COMMAND.Parameters.Clear()
            Next

            MsgBox("Successfully Saved", vbOKOnly + vbInformation, "System")
            loadProductStocks(Me.process_type)
            createSelectedItem_Rows()
            Index.InventoryForm.Inventorylist()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try
    End Sub
    
End Class