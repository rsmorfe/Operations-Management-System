﻿Public Class Discount_Details
    Public process_type As String
    'FOR EDIT PURPOSE ONLY
    Public disc_code As String
    Public disc_name As String
    Public disc_value As Double

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If process_type = "ADD" Then
            AddDiscount()
        ElseIf process_type = "EDIT" Then
            UpdateDiscount()
        End If
    End Sub

    Private Sub txtDiscValue_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDiscValue.KeyPress
        Dim DecimalSeparator As String = Application.CurrentCulture.NumberFormat.NumberDecimalSeparator
        e.Handled = Not (Char.IsDigit(e.KeyChar) Or
                         Asc(e.KeyChar) = 8 Or
                         (e.KeyChar = DecimalSeparator And sender.Text.IndexOf(DecimalSeparator) = -1))

        If Char.IsControl(e.KeyChar) Then
        ElseIf Char.IsDigit(e.KeyChar) OrElse e.KeyChar = "."c Then
            'If TextBox2.TextLength = 5 And TextBox2.Text.Contains(".") = False Then
            'TextBox2.AppendText(".")
            'Elseif
            If e.KeyChar = "." And txtDiscValue.Text.IndexOf(".") <> -1 Then
                e.Handled = True
            ElseIf Char.IsDigit(e.KeyChar) Then
                If txtDiscValue.Text.IndexOf(".") <> -1 Then
                    If txtDiscValue.Text.Length >= txtDiscValue.Text.IndexOf(".") + 3 Then
                        e.Handled = True
                    End If
                End If
            End If
        Else
            e.Handled = True
        End If
    End Sub

    Sub Initialize(process As String)
        process_type = process
        txtDiscCode.Clear()
        txtDiscName.Clear()
        txtDiscValue.Clear()

        If process = "ADD" Then
            btnAdd.Text = "Add"
            txtDiscCode.Focus()
        Else
            btnAdd.Text = "Update"
            txtDiscValue.Focus()
        End If
    End Sub

    Sub setDiscountValues(code As String, discName As String, discValue As Double)
        disc_code = code
        disc_name = discName
        disc_value = discValue

        txtDiscCode.Text = disc_code
        txtDiscName.Text = disc_name
        txtDiscValue.Text = (CDbl(disc_value))
    End Sub

    Sub AddDiscount()
        Dim result As Integer
        Dim sql As String

        sql = "insert into discounts(disc_code, disc_name, disc_value, disc_status)" _
               & "values(@disc_code, @disc_name, @disc_value, @status)"

        Dim status As Integer = 1
        Try
            'we open Connection
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@disc_code", txtDiscCode.Text)
                .Parameters.AddWithValue("@disc_name", txtDiscName.Text)
                .Parameters.AddWithValue("@disc_value", txtDiscValue.Text)
                .Parameters.AddWithValue("@status", status)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = COMMAND.ExecuteNonQuery
                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                    COMMAND.Parameters.Clear()
                    Exit Sub
                End If
            End With

            MsgBox("Successfully Saved", vbOKOnly + vbInformation, "System")
            COMMAND.Parameters.Clear()
            Discount.loadDiscounts() 'REFRESH LIST
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try


    End Sub

    Sub UpdateDiscount()
        Dim result As Integer
        Dim sql As String

        sql = "UPDATE discounts SET " _
            & "disc_name = @disc_name, disc_value = @disc_value " _
            & "WHERE disc_code = @code"

        Dim status As Integer = 1
        Try
            'we open Connection
            openConnection()

            With COMMAND
                .Connection = MysqlConn
                .CommandText = sql
                .Parameters.AddWithValue("@disc_name", txtDiscName.Text)
                .Parameters.AddWithValue("@disc_value", txtDiscValue.Text)
                .Parameters.AddWithValue("@code", disc_code)

                'in this line it Executes a transact-SQL statements against the connection and returns the number of rows affected 
                result = COMMAND.ExecuteNonQuery
                'if the result is equal to zero it means that no rows is inserted or somethings wrong during the execution
                If result = 0 Then
                    MsgBox("Something went wrong..", vbOKOnly + vbExclamation, "System")
                    COMMAND.Parameters.Clear()
                    Exit Sub
                End If
            End With

            MsgBox("Successfully Saved", vbOKOnly + vbInformation, "System")
            COMMAND.Parameters.Clear()
            Discount.loadDiscounts() 'REFRESH LIST
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            COMMAND.Parameters.Clear()
        End Try

    End Sub
End Class